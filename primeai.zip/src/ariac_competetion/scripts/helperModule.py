#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt,pi,atan2,cos,sin
from osrf_gear.msg import Proximity
from osrf_gear.msg import LogicalCameraImage
from osrf_gear.msg import Order
import time





class ArmController():
	def __init__(self,ns,noOfarm):
		moveit_commander.roscpp_initialize(sys.argv)
		self.robot = []
		self.scene = []
		self.move_group = []
		self.ns = []
		for i in range(noOfarm):
			robot = moveit_commander.RobotCommander(robot_description=ns+str(i+1)+"/robot_description",ns=ns+str(i+1))
			scene = moveit_commander.PlanningSceneInterface(ns=ns+str(i+1))
			group_name = "manipulator"
			move_group = moveit_commander.MoveGroupCommander(group_name,robot_description=ns+str(i+1)+"/robot_description",ns=ns+str(i+1))
			# print(robot.get_joint('linear_arm_actuator_joint').bounds())
			self.robot.append(robot)
			self.scene.append(scene)
			self.move_group.append(move_group)
			self.ns.append(ns+str(i+1))
		# print(self.ns)
		# move_group_wrist = moveit_commander.MoveGroupCommander("endeffector",robot_description=ns+"/robot_description",ns=ns)

		# planning_frame = move_group.get_planning_frame()
		# eef_link = move_group.get_end_effector_link()
		# group_names = robot.get_group_names()

		
		# self.move_group_wrist = move_group_wrist
		# self.planning_frame = planning_frame
		# self.eef_link = eef_link
		# self.group_names = group_names
		
		self.pickFlag = False
		self.modelsaveFlag = [True]*9
		self.models = {}
		self.received_orders = []
		self.cameraypose = [1.9135,1.1499,0.383,-0.383,-1.1504,-1.9135]
		self.tray1models = []
		self.tray2models = []


		self.indx = 0
		self.previousTime = 0
		self.refx = 0
		self.refy = 0
		self.refz = 0
		self.type = ""

		rospy.init_node('ariac_competetion_solution_node', anonymous=True)
		self.tfBuffer = tf2_ros.Buffer()
		self.listener = tf2_ros.TransformListener(self.tfBuffer)

		rospy.Subscriber("/ariac/break_beam_1_change",Proximity,self.breakbeam1Callback)
		rospy.Subscriber("/ariac/break_beam_2_change",Proximity,self.breakbeam2Callback)
		rospy.Subscriber("/ariac/break_beam_3_change",Proximity,self.breakbeam3Callback)

		rospy.Subscriber('/ariac/logical_camera_1',LogicalCameraImage,self.logicalCamera11Callback)
		rospy.Subscriber('/ariac/logical_camera_2',LogicalCameraImage,self.logicalCamera12Callback)
		
		rospy.Subscriber('/ariac/logical_camera_4',LogicalCameraImage,self.logicalCamera14Callback)
		rospy.Subscriber('/ariac/logical_camera_5',LogicalCameraImage,self.logicalCamera15Callback)
		rospy.Subscriber('/ariac/logical_camera_6',LogicalCameraImage,self.logicalCamera16Callback)
		rospy.Subscriber('/ariac/logical_camera_7',LogicalCameraImage,self.logicalCamera17Callback)
		rospy.Subscriber('/ariac/logical_camera_8',LogicalCameraImage,self.logicalCamera18Callback)
		rospy.Subscriber('/ariac/logical_camera_9',LogicalCameraImage,self.logicalCamera19Callback)
		
		rospy.Subscriber("/ariac/orders", Order, self.order_callback)

	def order_callback(self, msg):
		# rospy.loginfo("Received order:\n" + str(msg))
		# print(msg)
		self.received_orders.append(msg)

	def breakbeam1Callback(self,msg):
		if msg.object_detected and self.pickFlag:
			print("one object found")
			model = self.models[0]
			if model.type == self.type:
				self.refx = model.pose.position.x
				self.refy = model.pose.position.y
				self.refz = model.pose.position.z
				self.pickFlag = False
			del self.models[0]

	def breakbeam2Callback(self,msg):
		if msg.object_detected:
			# self.indx -= 1
			self.modelsaveFlag = True

	def breakbeam3Callback(self,msg):
		if msg.object_detected:#and (time.time() - self.previousTime) > 1:
			self.indx += 1
			# print('indx',self.indx)
			# self.previousTime = time.time()

	def logicalCamera11Callback(self,msg):
		self.tray1models = msg.models #it is a list
		# print(self.tray1models)
			

	def logicalCamera12Callback(self,msg):
		self.tray2models = msg.models #it is a list


	def logicalCamera13Callback(self,msg):

		if self.modelsaveFlag[2]:
			# print(msg.models)
			# print('************')
			models = msg.models #it is a list
			if models:
				self.models.append(models[-1])
			self.modelsaveFlag[2] = False
			
			# print((self.models))
		# print(models[0].type)
		# print(models[0].pose)
		# refPose = models[0].pose
		


	def logicalCamera14Callback(self,msg):
		if self.modelsaveFlag[3]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_4_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera14' in self.models:
						self.models['logicalCamera14'] = [model]
					else:
						self.models['logicalCamera14'].append(model)
				self.modelsaveFlag[3] = False
				# print(self.models)

	def logicalCamera15Callback(self,msg):
		if self.modelsaveFlag[4]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_5_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera15' in self.models:
						self.models['logicalCamera15'] = [model]
					else:
						self.models['logicalCamera15'].append(model)
				self.modelsaveFlag[4] = False
				# print(self.models)

	def logicalCamera16Callback(self,msg):
		if self.modelsaveFlag[5]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_6_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera16' in self.models:
						self.models['logicalCamera16'] = [model]
					else:
						self.models['logicalCamera16'].append(model)
				self.modelsaveFlag[5] = False
				# print(self.models)
	
	def logicalCamera17Callback(self,msg):
		if self.modelsaveFlag[6]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_7_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera17' in self.models:
						self.models['logicalCamera17'] = [model]
					else:
						self.models['logicalCamera17'].append(model)
				self.modelsaveFlag[6] = False
				# print(self.models)

	def logicalCamera18Callback(self,msg):
		if self.modelsaveFlag[7]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_8_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera18' in self.models:
						self.models['logicalCamera18'] = [model]
					else:
						self.models['logicalCamera18'].append(model)
				self.modelsaveFlag[7] = False
				# print(self.models)

	def logicalCamera19Callback(self,msg):
		if self.modelsaveFlag[8]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_9_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera19' in self.models:
						self.models['logicalCamera19'] = [model]
					else:
						self.models['logicalCamera19'].append(model)
				self.modelsaveFlag[8] = False
				# print(self.models)
			

	def gotoHome(self,armno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = 0 # linear_arm_actuator_joint
		joint_goal[1] = pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = pi/4 # elbow_joint 
		
		joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		joint_goal[5] = 0 #wrist_2_joint
		joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		# self.move_group[armno-1].stop()

	def gotoHomeAll(self):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[0].get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = 1.18 # linear_arm_actuator_joint
		joint_goal[1] = pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = pi/4 # elbow_joint 
		
		joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		joint_goal[5] = 0 #wrist_2_joint
		joint_goal[6] = 0 # wrist_3_joint

		self.move_group[0].go(joint_goal, wait=True)
		self.move_group[0].stop()

		joint_goal[0] = -1.18 
		joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		self.move_group[1].go(joint_goal, wait=True)
		self.move_group[1].stop()
	
	def turnToAGV(self,armno,agvno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] = 0 # linear_arm_actuator_joint
		if agvno==1:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		# joint_goal[2] = -pi/2 # shoulder_lift_joint
		# joint_goal[3] = 3*pi/4 # elbow_joint 
		
		# joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		# joint_goal[5] = 0 #wrist_2_joint
		# joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

	def goToAGV(self,armno,agvno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		
		if agvno==1:
			joint_goal[0] = 1.15 # linear_arm_actuator_joint
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[0] = -1.15 # linear_arm_actuator_joint
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 
		
		# joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		# joint_goal[5] = 0 #wrist_2_joint
		# joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

	def turnToBelt(self,armno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] = 0 # linear_arm_actuator_joint
		joint_goal[1] = 0 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 
		
		# joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		# joint_goal[5] = 0 #wrist_2_joint
		# joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

	def turnToBin(self,armno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] = 0 # linear_arm_actuator_joint
		joint_goal[1] = pi # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 
		
		# joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		# joint_goal[5] = 0 #wrist_2_joint
		# joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()
		# self.moveWristBin(armno)

	def goToCamera(self,armno,camerano):
		line_joint = 0
		
		if armno==1 and abs(min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==2 and abs(min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==1:
			line_joint = min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)
		elif armno==2:
			line_joint = min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = line_joint #-0.383 # linear_arm_actuator_joint
		# joint_goal[1] = pi # shoulder_pan_joint
		# joint_goal[2] = -pi/2 # shoulder_lift_joint
		# joint_goal[3] = 3.5*pi/4 # elbow_joint 
		
		# joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		# joint_goal[5] = 0 #wrist_2_joint
		# joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()
		# rospy.sleep(3)
		# self.moveWristBin(armno)
		return True
		
	def pickFromCamera(self,armno,pose):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		start_pose.position.x = pose.position.x
		start_pose.position.y = pose.position.y
		start_pose.position.z = pose.position.z+.033
		self.move_group[armno-1].set_pose_target(start_pose)
		self.move_group[armno-1].go(wait=True)
		# print("success")
		self.move_group[armno-1].stop()
		# self.move_group[armno-1].clear_pose_targets()
		# rospy.sleep(3)
		# self.moveWristBin(armno,enable=True)

	def placeToTray(self,armno,pose,kitTrayno,initPose=None):
		if kitTrayno == 1:
			frame = 'kit_tray_1'
		else:
			frame = 'kit_tray_2'
		# print(pose)
		gpose = self.getglobalpose(frame,pose)
		# print(gpose)

		start_pose = self.move_group[armno-1].get_current_pose().pose
		start_pose.position.x = gpose.pose.position.x
		start_pose.position.y = gpose.pose.position.y
		start_pose.position.z = gpose.pose.position.z+0.17
		self.move_group[armno-1].set_pose_target(start_pose)
		self.move_group[armno-1].go(wait=True)
		self.move_group[armno-1].stop()
		# self.move_group[armno-1].clear_pose_targets()
		
		# rospy.sleep(3)
		self.moveWristBin(armno)
		# if kitTrayno == 1:
		# 	frame2 = "arm1_tool0"
		# else:
		# 	frame2 = "arm2_tool0"

		# gpose = self.getglobalpose(,gpose.pose,frame2=frame2)
		# print(gpose)
		# joint_goal = self.move_group[armno-1].get_current_joint_values()

		# rpy = self.getrpy(gpose.pose)
		# if initPose != None:
		# 	rpy1 = self.getrpy(initPose)
		# 	print("rpy2:",rpy,rpy1)
		# # print("************")
		# joint_goal = self.move_group[armno-1].get_current_joint_values()
		# joint_goal[6] = rpy[2]-(joint_goal[1]+rpy1[2]) # wrist_3_joint

		# self.move_group[armno-1].go(joint_goal, wait=True)
		# self.move_group[armno-1].stop()
		return gpose.pose

	def setorientation(self,armno,pose):
		# print("tray models", self.tray1models)
		if armno==1:
			while True:
				if self.tray1models:
					# print("tray models1 ", self.tray1models)
					mind = 10e10
					minpos=None
					for model in self.tray1models:
						frame = 'logical_camera_1_frame'
						globalpose = self.getglobalpose(frame,model.pose)
						d = self.getdistance(pose,globalpose.pose)
						if d<mind:
							mind = d
							minpose = globalpose.pose
					if minpose != None:
						self.moveWristBin(armno)
						start_pose = self.move_group[armno-1].get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.033
						self.move_group[armno-1].set_pose_target(start_pose)
						self.move_group[armno-1].go(wait=True)
						self.move_group[armno-1].stop()
						self.moveWristBin(armno)
						start_pose = self.move_group[armno-1].get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.15
						self.move_group[armno-1].set_pose_target(start_pose)
						self.move_group[armno-1].go(wait=True)
						self.move_group[armno-1].stop()
						self.moveWristBin(armno)
						# rospy.sleep(1)
						# print(self.getrpy(pose),self.getrpy(minpose))
						# pose = self.getglobalpose("world",pose,frame2="arm1_tool0")
						# minpose = self.getglobalpose("world",minpose,frame2="arm1_tool0")
						rpy1 = self.getrpy(pose)
						rpy2 = self.getrpy(minpose)
						
						joint_goal = self.move_group[armno-1].get_current_joint_values()
						print("rpy",rpy1[2],rpy2[2],joint_goal[6])
						if rpy1[2]<0:
							joint_goal[6] -= rpy1[2]-rpy2[2] #*(-rpy1[2]/(abs(rpy1[2])+0.0000001))  #+joint_goal[1]# wrist_3_joint
							# joint_goal[6] = min(2*pi,joint_goal[6])
						else:
							joint_goal[6] -= rpy1[2]-rpy2[2]
							# joint_goal[6] = min(2*pi,joint_goal[6])

						self.move_group[armno-1].go(joint_goal, wait=True)
						self.move_group[armno-1].stop()
					break
				rospy.sleep(1)



	def getdistance(self,pose1,pose2):
		d=(pose1.position.x-pose2.position.x)**2
		d+=(pose1.position.y-pose2.position.y)**2
		d+=(pose1.position.z-pose2.position.z)**2
		return d

	

	def moveWristBin(self,armno,enable=False):
		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		# desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		desired_angle = 3*pi/2-(joint_goal[2]+joint_goal[3])
		joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		# joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		# desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		# joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()
		

	def getrpy(self,pose):
		quaternion = (
		pose.orientation.x,
		pose.orientation.y,
		pose.orientation.z,
		pose.orientation.w)
		euler = tf.transformations.euler_from_quaternion(quaternion)
		roll = euler[0]
		pitch = euler[1]
		yaw = euler[2]
		return euler

	def getglobalpose(self,frame,pose,frame2="none"):
		while not rospy.is_shutdown():
			try:
				if frame2=="none":
					trans = self.tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, 'world')
					return world_pose	
				else:
					trans = self.tfBuffer.lookup_transform(frame2, frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, frame2)
					return world_pose

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				print(e)
				continue

	def checkOrder(self):
		self.gotoHomeAll()
		ariac_example.start_competition()
		# rospy.sleep(1)
		rate = rospy.Rate(1.0)
		while not rospy.is_shutdown():
			if self.received_orders:
				order = self.received_orders[0]
				# print(order)
				shipments = order.shipments
				for shipment in shipments:
					products = shipment.products
					for product in products:
						producttype = product.type
						productpos = product.pose

						keys = self.models.keys()
						for key in keys:
							allModels = self.models[key]
							flag = False
							indx = -1
							for model in allModels:
								# print(model)
								indx = indx + 1
								if model.type == producttype:
									camerano = int(key[-1])
									pose = model.pose
									print(camerano)
									self.turnToBin(1)
									flag1 = True
									if self.goToCamera(1,camerano):
										del self.models[key][indx]
										print('arm1 can pick')
										ariac_example.control_gripper(True, 1)
										self.moveWristBin(1)
										self.pickFromCamera(1,pose)
										self.moveWristBin(1)
										self.turnToBin(1)
										self.turnToAGV(1,1)
										self.goToAGV(1,1)
										self.moveWristBin(1)
										gtraypose = self.placeToTray(1,productpos,1,initPose=pose)
										ariac_example.control_gripper(False, 1)
										self.goToAGV(1,1)
										ariac_example.control_gripper(True, 1)
										self.moveWristBin(1)
										self.setorientation(1,gtraypose)
										ariac_example.control_gripper(False, 1)
										rospy.sleep(1)
										self.goToAGV(1,1)
										flag1 = False

									if flag1:
										self.turnToBin(2)
										if self.goToCamera(2,camerano):
											del self.models[key][indx]
											print('arm2 can pick')
											ariac_example.control_gripper(True, 2)
											self.moveWristBin(2)
											self.pickFromCamera(2,pose)
											self.moveWristBin(2)
											self.turnToBin(2)
											self.turnToAGV(2,2)
											self.goToAGV(2,2)
											self.moveWristBin(2)
											gtraypose = self.placeToTray(2,productpos,2,initPose=pose)
											ariac_example.control_gripper(False, 2)
											self.goToAGV(2,2)
											# ariac_example.control_gripper(True, 2)
											# self.moveWristBin(2)
											# self.setorientation(2,gtraypose)
											# ariac_example.control_gripper(False, 2)
											# rospy.sleep(1)
											# self.goToAGV(2,2)
											

									flag = True
									break
							if flag:
								break

					# print(shipment)
					# ariac_example.submit_shipment(shipment.shipment_type, agv_num=1)
					# rospy.sleep(3)
					# ariac_example.control_agv(shipment.shipment_type, 1)
					# rospy.sleep(3)
					

				
				del self.received_orders[0]
			rate.sleep()

				
