#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt,pi,atan2,cos,sin
# from helperModule import ArmController
from armController import ArmController


from osrf_gear.msg import Proximity

from osrf_gear.msg import Order
import time




pickFlag = False
modelsaveFlag = [True]*9
models = {}
received_orders = []
tray1models = []
tray2models = []
indx = 0

def order_callback(msg):
	global received_orders
	received_orders.append(msg)

def breakbeam1Callback(msg):
	if msg.object_detected and pickFlag:
		print("one object found")
		model = models[0]
		if model.type == type:
			refx = model.pose.position.x
			refy = model.pose.position.y
			refz = model.pose.position.z
			pickFlag = False
		del models[0]

def breakbeam2Callback(msg):
	if msg.object_detected:
		# indx -= 1
		modelsaveFlag = True

def breakbeam3Callback(msg):
	if msg.object_detected:#and (time.time() - previousTime) > 1:
		indx += 1
		# print('indx',indx)
		# previousTime = time.time()

def logicalCamera11Callback(msg):
	global tray1models
	tray1models = msg.models #it is a list
	# print(tray1models)
		

def logicalCamera12Callback(msg):
	global tray2models
	tray2models = msg.models #it is a list


def logicalCamera13Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[2]:
		# print(msg.models)
		# print('************')
		modelscb = msg.models #it is a list
		if modelscb:
			models.append(models[-1])
		modelsaveFlag[2] = False
		
		# print((models))
	# print(models[0].type)
	# print(models[0].pose)
	# refPose = models[0].pose
	


def logicalCamera14Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[3]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_4_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera14' in models:
					models['logicalCamera14'] = [model]
				else:
					models['logicalCamera14'].append(model)
			modelsaveFlag[3] = False
			# print(models)

def logicalCamera15Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[4]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_5_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera15' in models:
					models['logicalCamera15'] = [model]
				else:
					models['logicalCamera15'].append(model)
			modelsaveFlag[4] = False
			# print(models)

def logicalCamera16Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[5]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_6_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera16' in models:
					models['logicalCamera16'] = [model]
				else:
					models['logicalCamera16'].append(model)
			modelsaveFlag[5] = False
			

def logicalCamera17Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[6]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_7_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera17' in models:
					models['logicalCamera17'] = [model]
				else:
					models['logicalCamera17'].append(model)
			modelsaveFlag[6] = False
			

def logicalCamera18Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[7]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_8_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera18' in models:
					models['logicalCamera18'] = [model]
				else:
					models['logicalCamera18'].append(model)
			modelsaveFlag[7] = False
			

def logicalCamera19Callback(msg):
	global modelsaveFlag
	global models
	if modelsaveFlag[8]:
		modelscb = msg.models #it is a list
		if modelscb:
			frame = 'logical_camera_9_frame' 
			for model in modelscb:
				pose=model.pose
				gpose=getglobalpose(frame,pose)
				model.pose = gpose.pose
				if not 'logicalCamera19' in models:
					models['logicalCamera19'] = [model]
				else:
					models['logicalCamera19'].append(model)
			modelsaveFlag[8] = False
				

def getglobalpose(frame,pose,frame2="none"):
	global tfBuffer
	while not rospy.is_shutdown():
		try:
			if frame2=="none":
				trans = tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
				
				local_pose = geometry_msgs.msg.PoseStamped()
				local_pose.header.frame_id = frame
				local_pose.pose=pose

				world_pose = tfBuffer.transform(local_pose, 'world')
				return world_pose	
			else:
				trans = tfBuffer.lookup_transform(frame2, frame, rospy.Time(), rospy.Duration(1.0))
				
				local_pose = geometry_msgs.msg.PoseStamped()
				local_pose.header.frame_id = frame
				local_pose.pose=pose

				world_pose = tfBuffer.transform(local_pose, frame2)
				return world_pose

		except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
			print(e)
			continue

		
def checkOrder():
		global models
		arm1.gotoHome(1)
		arm2.gotoHome(2)
		# ariac_example.start_competition()
		
		rate = rospy.Rate(1.0)
		while not rospy.is_shutdown():
			if received_orders:
				order = received_orders[0]
				# print(order)
				shipments = order.shipments
				for shipment in shipments:
					products = shipment.products
					for product in products:
						producttype = product.type
						productpos = product.pose

						keys = models.keys()
						for key in keys:
							allModels = models[key]
							flag = False
							indx = -1
							for model in allModels:
								# print(model)
								indx = indx + 1
								if model.type == producttype:
									camerano = int(key[-1])
									pose = model.pose
									print(camerano)
									arm1.turnToBin(1)
									flag1 = True
									if arm1.goToCamera(1,camerano):
										del models[key][indx]
										print('arm',1,' can pick')
										ariac_example.control_gripper(True, 1)
										arm1.moveWristBin(1)
										arm1.pickFromCamera(1,pose,producttype)
										arm1.moveWristBin(1)
										arm1.turnToBin(1)
										arm1.turnToAGV(1,1)
										arm1.goToAGV(1,1)
										arm1.moveWristBin(1)
										productpos = getglobalpose('kit_tray_1',productpos)
										gtraypose = arm1.placeToTray(1,productpos,1,initPose=pose)
										ariac_example.control_gripper(False, 1)
										rospy.sleep(2)
										arm1.goToAGV(1,1)
										ariac_example.control_gripper(True, 1)
										arm1.moveWristBin(1)
										# arm1.setorientation(1,gtraypose,producttype)
										# arm1.ariac_example.control_gripper(False, 1)
										# rospy.sleep(2)
										# arm1.goToAGV(1,1)
										flag1 = False
									if flag1:
										arm2.turnToBin(2)
										if arm2.goToCamera(2,camerano):
											del models[key][indx]
											print('arm',2,' can pick')
											ariac_example.control_gripper(True, 2)
											arm2.moveWristBin(2)
											arm2.pickFromCamera(2,pose,producttype)
											arm2.moveWristBin(2)
											arm2.turnToBin(2)
											arm2.turnToAGV(2,2)
											arm2.goToAGV(2,2)
											arm2.moveWristBin(2)
											productpos = getglobalpose('kit_tray_1',productpos)
											gtraypose = arm2.placeToTray(2,productpos,2,initPose=pose)
											ariac_example.control_gripper(False, 2)
											rospy.sleep(2)
											arm2.goToAGV(2,2)
											ariac_example.control_gripper(True, 2)
											arm2.moveWristBin(2)
											# arm2.setorientation(2,gtraypose,producttype)
											# arm2.ariac_example.control_gripper(False, 2)
											# rospy.sleep(2)
											# arm2.goToAGV(2,2)
										

									flag = True
									break
							if flag:
								break

					# print(shipment)
					# ariac_example.submit_shipment(shipment.shipment_type, agv_num=1)
					# rospy.sleep(3)
					# ariac_example.control_agv(shipment.shipment_type, 1)
					# rospy.sleep(3)
					

				
				del received_orders[0]
			rate.sleep()



	




if __name__ == '__main__':
	try:
		# rospy.init_node('ariac_competetion_solution_node1', anonymous=True)
		# noOfarm = 2
		# arm = ArmController("/ariac/arm",noOfarm)
		arm1 = ArmController("/ariac/arm1",1)
		arm1.checkOrder(1)
		# arm2 = ArmController("/ariac/arm2",2)
		# arm2.checkOrder(2)


		# tfBuffer = tf2_ros.Buffer()
		# listener = tf2_ros.TransformListener(tfBuffer)

		# rospy.Subscriber("/ariac/break_beam_1_change",Proximity,breakbeam1Callback)
		# rospy.Subscriber("/ariac/break_beam_2_change",Proximity,breakbeam2Callback)
		# rospy.Subscriber("/ariac/break_beam_3_change",Proximity,breakbeam3Callback)

		# rospy.Subscriber('/ariac/logical_camera_1',LogicalCameraImage,logicalCamera11Callback)
		# rospy.Subscriber('/ariac/logical_camera_2',LogicalCameraImage,logicalCamera12Callback)
		
		# rospy.Subscriber('/ariac/logical_camera_4',LogicalCameraImage,logicalCamera14Callback)
		# rospy.Subscriber('/ariac/logical_camera_5',LogicalCameraImage,logicalCamera15Callback)
		# rospy.Subscriber('/ariac/logical_camera_6',LogicalCameraImage,logicalCamera16Callback)
		# rospy.Subscriber('/ariac/logical_camera_7',LogicalCameraImage,logicalCamera17Callback)
		# rospy.Subscriber('/ariac/logical_camera_8',LogicalCameraImage,logicalCamera18Callback)
		# rospy.Subscriber('/ariac/logical_camera_9',LogicalCameraImage,logicalCamera19Callback)
		
		# rospy.Subscriber("/ariac/orders", Order, order_callback)

		# checkOrder()

		# rospy.init_node('ariac_competetion_solution_node', anonymous=True)
		#arm.gotoHomeAll()
		# arm.checkOrder()
		# arm.turnToBin(1)
		# arm.goToCamera(1,6)

		# arm.gotoHome(1)

		# arm.turnToBin(1)
		# rospy.sleep(1)
		# arm.goToCamera6(1)
		# rospy.sleep(1)
		# arm.pickFromCamera6(1)
		# rospy.sleep(1)
		# arm.turnToBin(1)
		# rospy.sleep(1)
		# arm.turnToAGV(1,1)
		# rospy.sleep(1)
		# arm.goToAGV(1,1)
		# rospy.sleep(1)
		# arm.placeToTray(1,1)
		# rospy.sleep(1)
		# arm.goToAGV(1,1)
		# rospy.sleep(1)
		# comp_class = ariac_example.MyCompetitionClass()
		# ariac_example.connect_callbacks(comp_class)
		
		# # rospy.loginfo("Setup complete.")
		# # # ariac_example.start_competition()

		# if not comp_class.arm_1_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_1_joint_trajectory_publisher)
		#     comp_class.arm_1_has_been_zeroed = True

		# if not comp_class.arm_2_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_2_joint_trajectory_publisher)
		#     comp_class.arm_2_has_been_zeroed = True

		# golepose = geometry_msgs.msg.Pose() 
		# golepose.position.x = 1.22
		# golepose.position.y = 2.0
		# golepose.position.z = 0.91
		# arm.gotoLocation(1,golepose)
		# arm.pick(1,"gear_part")#"gear_part") #"piston_rod_part"
		# rospy.sleep(3)
		# arm1.gotoHome()
		# rospy.sleep(3)
		# golepose.position.x = 0.3
		# golepose.position.y = 3.15
		# golepose.position.z = 0.75
		# arm1.place(golepose)
		# arm1.pick()
		


		# tfBuffer = tf2_ros.Buffer()
		# listener = tf2_ros.TransformListener(tfBuffer)

		# # The shipping box TF frames are published by logical cameras, or can be published
		# # by user-created TF broadcasters.
		# frame = 'kit_tray_1'#'logical_camera_1_frame' #frame = 'shipping_box_frame'
		# rate = rospy.Rate(1.0)
		# # flag2 = True
		# while not rospy.is_shutdown():
		# # Ensure that the transform is available.
		# 	try:
		# 		trans = tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
		# 		local_pose = geometry_msgs.msg.PoseStamped()
		# 		local_pose.header.frame_id = frame
		# 		local_pose.pose.position.x = 0
		# 		local_pose.pose.position.y = 0
		# 		local_pose.pose.position.z = 0
		# 		world_pose = tfBuffer.transform(local_pose, 'world')
		# 		print(world_pose)
		# 		# arm1.move(world_pose.pose)
		# 		break

		# 	except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
		# 		print(e)
		# 		continue

			# Transform the pose from the specified frame to the world frame.
			# local_pose = geometry_msgs.msg.PoseStamped()
			# local_pose.header.frame_id = frame
			# local_pose.pose.position.x = 0.15
			# local_pose.pose.position.y = 0.15
			# # print(refPose)
			# if not flag and flag2:
			# 	flag2 = False
			# 	local_pose.pose = refPose
			# 	world_pose = tfBuffer.transform(local_pose, 'world')
			# 	# arm1.move(world_pose.pose)
			# 	# print(world_pose)
			# arm.checkOrder()
			# rate.sleep()
		# print("get out of loop",rospy.is_shutdown())	
		# arm1.moveWrist()
		# rospy.spin()

	except Exception as e:
		print(e)
