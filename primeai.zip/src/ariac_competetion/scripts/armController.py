#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt,pi,atan2,cos,sin
from osrf_gear.msg import Proximity
from osrf_gear.msg import LogicalCameraImage
from osrf_gear.msg import Order
import time
from std_msgs.msg import String




class ArmController():
	def __init__(self,ns,armno):
		rospy.init_node('ariac_competetion_solution_node'+str(armno), anonymous=True)
		rospy.sleep(3)

		moveit_commander.roscpp_initialize(sys.argv)
		self.robot = moveit_commander.RobotCommander(robot_description=ns+"/robot_description",ns=ns)
		self.scene = moveit_commander.PlanningSceneInterface(ns=ns)
		self.group_name = "manipulator"
		self.move_group = moveit_commander.MoveGroupCommander(self.group_name,robot_description=ns+"/robot_description",ns=ns)
		
		
		self.pickFlag = False
		self.modelsaveFlag = [True]*9
		self.models = {}
		self.beltModels=[]
		self.received_orders = []
		self.cameraypose = [1.9135,1.1499,0.383,-0.383,-1.1504,-1.9135]
		self.attachth={"gasket_part":0.03,"piston_rod_part":0.01,"pulley_part":0.07,"gear_part":0.03,"disk_part":0.035}
		# self.attachth={"gasket_part":0.035,"piston_rod_part":0.015,"pulley_part":0.075,"gear_part":0.035,"disk_part":0.035}

		self.tray1models = []
		self.tray2models = []


		self.indx = 0
		self.previousTime = 0
		self.refx = 0
		self.refy = 0
		self.refz = 0
		self.type = ""

		
		self.tfBuffer = tf2_ros.Buffer()
		self.listener = tf2_ros.TransformListener(self.tfBuffer)
		self.command = ""
		self.armnoWorking = "default"
		self.beltStop = False

		self.commandpub = rospy.Publisher('/slavecommand', String, queue_size=10)
		rospy.Subscriber('/slavecommand', String, self.commmandCallback)

		rospy.Subscriber("/ariac/break_beam_1_change",Proximity,self.breakbeam1Callback)
		rospy.Subscriber("/ariac/break_beam_2_change",Proximity,self.breakbeam2Callback)
		rospy.Subscriber("/ariac/break_beam_3_change",Proximity,self.breakbeam3Callback)

		rospy.Subscriber('/ariac/logical_camera_1',LogicalCameraImage,self.logicalCamera11Callback)
		rospy.Subscriber('/ariac/logical_camera_2',LogicalCameraImage,self.logicalCamera12Callback)

		rospy.Subscriber('/ariac/logical_camera_3',LogicalCameraImage,self.logicalCamera13Callback)
		
		rospy.Subscriber('/ariac/logical_camera_4',LogicalCameraImage,self.logicalCamera14Callback)
		rospy.Subscriber('/ariac/logical_camera_5',LogicalCameraImage,self.logicalCamera15Callback)
		rospy.Subscriber('/ariac/logical_camera_6',LogicalCameraImage,self.logicalCamera16Callback)
		rospy.Subscriber('/ariac/logical_camera_7',LogicalCameraImage,self.logicalCamera17Callback)
		rospy.Subscriber('/ariac/logical_camera_8',LogicalCameraImage,self.logicalCamera18Callback)
		rospy.Subscriber('/ariac/logical_camera_9',LogicalCameraImage,self.logicalCamera19Callback)
		
		rospy.Subscriber("/ariac/orders", Order, self.order_callback)

	def commmandCallback(self,msg):
		self.command = msg.data
		if "working" in msg.data:
			self.armnoWorking = msg.data
		print(msg)


	def order_callback(self, msg):
		# rospy.loginfo("Received order:\n" + str(msg))
		# print(msg)
		self.received_orders.append(msg)

	def breakbeam1Callback(self,msg):
		if msg.object_detected and self.pickFlag:
			print("one object found")
			model = self.models[0]
			if model.type == self.type:
				self.refx = model.pose.position.x
				self.refy = model.pose.position.y
				self.refz = model.pose.position.z
				self.pickFlag = False
			del self.models[0]

	def breakbeam2Callback(self,msg):
		if msg.object_detected:
			# self.indx -= 1
			self.modelsaveFlag = True

	def breakbeam3Callback(self,msg):
		if msg.object_detected:#and (time.time() - self.previousTime) > 1:
			self.indx += 1
			# print('indx',self.indx)
			# self.previousTime = time.time()

	def logicalCamera13Callback(self,msg):
		models = msg.models #it is a list
		if models:
			# if not self.beltStop:
			# ariac_example.stop_belt()
				# self.beltStop = True

			frame = 'logical_camera_3_frame' 
			for model in models:
				pose=model.pose
				gpose=self.getglobalpose(frame,pose)
				model.pose = gpose.pose
			self.beltModels = models
		else:
			# ariac_example.start_belt()
			pass
			
			
			

	def logicalCamera11Callback(self,msg):
		self.tray1models = msg.models #it is a list
		# print(self.tray1models)		

	def logicalCamera12Callback(self,msg):
		self.tray2models = msg.models #it is a list
	

	def logicalCamera14Callback(self,msg):
		if self.modelsaveFlag[3]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_4_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera14' in self.models:
						self.models['logicalCamera14'] = [model]
					else:
						self.models['logicalCamera14'].append(model)
				self.modelsaveFlag[3] = False
				# print(self.models)

	def logicalCamera15Callback(self,msg):
		if self.modelsaveFlag[4]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_5_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera15' in self.models:
						self.models['logicalCamera15'] = [model]
					else:
						self.models['logicalCamera15'].append(model)
				self.modelsaveFlag[4] = False
				# print(self.models)

	def logicalCamera16Callback(self,msg):
		if self.modelsaveFlag[5]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_6_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera16' in self.models:
						self.models['logicalCamera16'] = [model]
					else:
						self.models['logicalCamera16'].append(model)
				self.modelsaveFlag[5] = False
				# print(self.models)
	
	def logicalCamera17Callback(self,msg):
		if self.modelsaveFlag[6]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_7_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera17' in self.models:
						self.models['logicalCamera17'] = [model]
					else:
						self.models['logicalCamera17'].append(model)
				self.modelsaveFlag[6] = False
				# print(self.models)

	def logicalCamera18Callback(self,msg):
		if self.modelsaveFlag[7]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_8_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera18' in self.models:
						self.models['logicalCamera18'] = [model]
					else:
						self.models['logicalCamera18'].append(model)
				self.modelsaveFlag[7] = False
				# print(self.models)

	def logicalCamera19Callback(self,msg):
		if self.modelsaveFlag[8]:
			models = msg.models #it is a list
			if models:
				frame = 'logical_camera_9_frame' 
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera19' in self.models:
						self.models['logicalCamera19'] = [model]
					else:
						self.models['logicalCamera19'].append(model)
				self.modelsaveFlag[8] = False
				# print(self.models)
			
	def gotoHome(self,armno):
		# self.move_group.set_named_target("home")
		# self.move_group.set_named_target("up")
		# print(self.move_group.go(wait=True))

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		if armno==1:
			joint_goal[0] = 1.18 # linear_arm_actuator_joint
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==2:
			joint_goal[0] = -1.18 # linear_arm_actuator_joint
			joint_goal[1] = 3*pi/2 # shoulder_pan_join
		
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = pi/4 # elbow_joint 
		
		joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		joint_goal[5] = 0 #wrist_2_joint
		joint_goal[6] = 0 # wrist_3_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		rospy.sleep(1)
		# self.move_group.stop()
	
	def turnToAGV(self,armno,agvno):
		joint_goal = self.move_group.get_current_joint_values()
		if agvno==1:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def goToAGV(self,armno,agvno):

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		
		if agvno==1:
			joint_goal[0] = 1.15 # linear_arm_actuator_joint
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[0] = -1.15 # linear_arm_actuator_joint
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 
		

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def goToAGVOnlyY(self,armno,agvno):
		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		
		if agvno==1:
			joint_goal[0] = 1.15 # linear_arm_actuator_joint
			
		elif agvno==2:
			joint_goal[0] = -1.15 # linear_arm_actuator_joint
		
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def turnToBelt(self,armno):

		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[1] = 0 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def turnToBin(self,armno):
		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[1] = pi # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def goToCamera(self,armno,camerano):
		line_joint = 0
		
		if armno==1 and abs(min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==2 and abs(min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==1:
			line_joint = min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)
		elif armno==2:
			line_joint = min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = line_joint 
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		return True
		
	def pickFromCamera(self,armno,pose,type):
		print(type)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = pose.position.x
		start_pose.position.y = pose.position.y
		start_pose.position.z = pose.position.z+0.1#self.attachth[type]
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = pose.position.x
		start_pose.position.y = pose.position.y
		start_pose.position.z = pose.position.z+self.attachth[type]
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def placeToTray(self,armno,pose,kitTrayno,initPose=None):
		if kitTrayno == 1:
			frame = 'kit_tray_1'
		else:
			frame = 'kit_tray_2'
		# print(pose)
		gpose = self.getglobalpose(frame,pose)
		# print(gpose)
		# gpose = pose
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = gpose.pose.position.x
		start_pose.position.y = gpose.pose.position.y
		start_pose.position.z = gpose.pose.position.z+0.17
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		self.moveWristBin(armno)
		return gpose.pose

	def setorientation(self,armno,pose,type):
		if type == "gear_part" or type == "pulley_part" or type == "disk_part":
			return
		if armno==1:
			while True:
				if self.tray1models:
					# print("tray models1 ", self.tray1models)
					mind = 10e10
					minpos=None
					for model in self.tray1models:
						frame = 'logical_camera_1_frame'
						globalpose = self.getglobalpose(frame,model.pose)
						d = self.getdistance(pose,globalpose.pose)
						if d<mind:
							mind = d
							minpose = globalpose.pose
					if minpose != None:
						joint_goal = self.move_group.get_current_joint_values()
						joint_goal[6] = 0 
						print(joint_goal[6])
						try:
							self.move_group.go(joint_goal, wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						self.moveWristBin(armno)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.1
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+self.attachth[type]
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						self.moveWristBin(armno)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.15
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						self.moveWristBin(armno)
						rpy1 = self.getrpy(pose)
						rpy2 = self.getrpy(minpose)
						
						joint_goal = self.move_group.get_current_joint_values()
						print("rpy",rpy1[2],rpy2[2],joint_goal[6])
						
						joint_goal[6] -= rpy1[2]-rpy2[2] 
						
						try:
							self.move_group.go(joint_goal, wait=True)
						except Exception as e:
							print(e)

						self.move_group.stop()
						rospy.sleep(1)
					break
				rospy.sleep(1)
		elif armno==2:
			while True:
				if self.tray2models:
					# print("tray models1 ", self.tray1models)
					mind = 10e10
					minpos=None
					for model in self.tray2models:
						frame = 'logical_camera_2_frame'
						globalpose = self.getglobalpose(frame,model.pose)
						d = self.getdistance(pose,globalpose.pose)
						if d<mind:
							mind = d
							minpose = globalpose.pose
					if minpose != None:
						joint_goal = self.move_group.get_current_joint_values()
						joint_goal[6] = 0 
						print(joint_goal[6])
						try:
							self.move_group.go(joint_goal, wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						self.moveWristBin(armno)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.1
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+self.attachth[type]
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
						self.moveWristBin(armno)
						start_pose = self.move_group.get_current_pose().pose
						start_pose.position.x = minpose.position.x
						start_pose.position.y = minpose.position.y
						start_pose.position.z = minpose.position.z+0.15
						self.move_group.set_pose_target(start_pose)
						try:
							self.move_group.go(wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						self.moveWristBin(armno)
						rpy1 = self.getrpy(pose)
						rpy2 = self.getrpy(minpose)
						
						joint_goal = self.move_group.get_current_joint_values()
						print("rpy",rpy1[2],rpy2[2],joint_goal[6])
						joint_goal[6] -= rpy1[2]-rpy2[2] 
						print(joint_goal[6])
						try:
							self.move_group.go(joint_goal, wait=True)
						except Exception as e:
							print(e)
						self.move_group.stop()
						rospy.sleep(1)
					break
				rospy.sleep(1)

	def getdistance(self,pose1,pose2):
		d=(pose1.position.x-pose2.position.x)**2
		d+=(pose1.position.y-pose2.position.y)**2
		d+=(pose1.position.z-pose2.position.z)**2
		return d

	def moveWristBin(self,armno,enable=False):
		joint_goal = self.move_group.get_current_joint_values()
		desired_angle = 3*pi/2-(joint_goal[2]+joint_goal[3])
		joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)

	def getrpy(self,pose):
		quaternion = (
		pose.orientation.x,
		pose.orientation.y,
		pose.orientation.z,
		pose.orientation.w)
		euler = tf.transformations.euler_from_quaternion(quaternion)
		roll = euler[0]
		pitch = euler[1]
		yaw = euler[2]
		return euler

	def getglobalpose(self,frame,pose,frame2="none"):
		while not rospy.is_shutdown():
			try:
				if frame2=="none":
					trans = self.tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, 'world')
					return world_pose	
				else:
					trans = self.tfBuffer.lookup_transform(frame2, frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, frame2)
					return world_pose

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				print(e)
				continue

	def putToZero(self,armno):
		joint_goal = self.move_group.get_current_joint_values()
		if armno==2:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==1:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 1.177
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		self.moveWristBin(armno)
		ariac_example.control_gripper(False, armno)
		rospy.sleep(1)	

	def pickFromzero(self,armno,producttype,productpos):
		joint_goal = self.move_group.get_current_joint_values()
		if armno==2:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==1:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		if armno == 1:
			self.goToCamera(armno,6)
		else:
			self.goToCamera(armno,7)
		# print(".................Go to Position .................. ")
		ariac_example.control_gripper(True, armno)
		rospy.sleep(1)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 1.15
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		self.moveWristBin(armno)
		rospy.sleep(1)
		# print(".................Pick the object.................. ")
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 0.943+self.attachth[producttype]
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		self.moveWristBin(armno)
		rospy.sleep(1)
		# print(".................Up the Object .................. ")
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 1.15
		self.move_group.set_pose_target(start_pose)
		try:
			self.move_group.go(wait=True)
		except Exception as e:
			print(e)
		self.move_group.stop()
		rospy.sleep(1)
		# print("................. Turn to the object .................. ")

	def putTozeroCheck(self,armno,producttype,cmd):
		keys = self.models.keys()
		for key in keys:
			allModels = self.models[key]
			flag = False
			indx = -1
			for model in allModels:
				# print(model)
				indx = indx + 1
				if model.type == producttype:
					camerano = int(key[-1])
					pose = model.pose
					print(camerano)
					self.turnToBin(armno)
					if self.goToCamera(armno,camerano):
						del self.models[key][indx]
						print('arm',armno,' can pick')
						ariac_example.control_gripper(True, armno)
						rospy.sleep(2)
						self.moveWristBin(armno)
						self.pickFromCamera(armno,pose,producttype)
						self.moveWristBin(armno)
						self.turnToBin(armno)
						if armno == 1:
							self.goToCamera(armno,6)
						else:
							self.goToCamera(armno,7)
						self.putToZero(armno)
						self.turnToAGV(armno,armno)
						self.commandpub.publish(cmd+"done")
						return								

	def putTozeroFrombelt(self,armno,producttype,cmd):
		flagdone = False 
		while not flagdone:
			rospy.sleep(1)
			if self.beltModels and armno==1:
				for model in self.beltModels:
					if model.type == producttype:
						pose = model.pose
						ariac_example.control_gripper(True, armno)
						self.turnToBelt(armno)
						rospy.sleep(2)
						self.goToAGVOnlyY(armno,armno)
						rospy.sleep(2)
						self.moveWristBin(armno)
						rospy.sleep(2)
						self.pickFromCamera(armno,pose,producttype)
						rospy.sleep(2)
						self.moveWristBin(armno)
						rospy.sleep(2)
						self.turnToBelt(armno)
						if armno == 1:
							self.goToCamera(armno,6)
						else:
							self.goToCamera(armno,7)
						rospy.sleep(2)
						self.putToZero(armno)
						rospy.sleep(2)
						self.turnToAGV(armno,armno)
						self.commandpub.publish(cmd+"done")
						return
					
			# self.beltStop = True
			# ariac_example.start_belt()
			# rospy.sleep(2)
			self.beltStop = False
					

	def pick_place(self,armno_real):
		delay = 3

		if self.received_orders and len(self.received_orders)>0:
			
			order = self.received_orders[0]
			# print(order)
			shipments = order.shipments
			for shipment in shipments:
				# print(shipment)
				armno = 0
				if ('agv1'==shipment.agv_id or 'any'==shipment.agv_id) and armno_real != 2:
					armno = 1
					cmd = "arm1 working"
					self.commandpub.publish(cmd)
				elif armno_real == 2 and "arm1 working" == self.armnoWorking or self.armnoWorking == "default":
					return
				elif 'agv2'==shipment.agv_id:
					armno = 2

				if armno_real!=armno:
					continue

				print("armno: ",armno,shipment)
				print("**************************************************************")
				products = shipment.products
				for product in products:
					producttype = product.type
					productpos = product.pose
					flag = False
					if self.models:
						keys = self.models.keys()
						flag = False
						for key in keys:
							allModels = self.models[key]
							flag = False
							indx = -1
							for model in allModels:
								# print(model)
								indx = indx + 1
								if model.type == producttype:
									camerano = int(key[-1])
									pose = model.pose
									print("camera no", camerano)
									self.turnToBin(armno)
									flag1 = True
									if self.goToCamera(armno,camerano):
										del self.models[key][indx]
										print('arm',armno,' can pick')
										ariac_example.control_gripper(True, armno)
										rospy.sleep(2)
										self.moveWristBin(armno)
										self.pickFromCamera(armno,pose,producttype)
										self.moveWristBin(armno)
										self.turnToBin(armno)
										
										self.turnToAGV(armno,armno)
										self.goToAGV(armno,armno)
										self.moveWristBin(armno)
										gtraypose = self.placeToTray(armno,productpos,armno,initPose=pose)
										ariac_example.control_gripper(False, armno)
										self.goToAGV(armno,armno)
										ariac_example.control_gripper(True, armno)
										self.moveWristBin(armno)
										self.setorientation(armno,gtraypose,producttype)
										ariac_example.control_gripper(False, armno)
										rospy.sleep(1)
										self.goToAGV(armno,armno)
										flag1 = False
									if flag1:
										del self.models[key][indx]
										cmd = "puttozero"+str(armno)+" "+producttype
										self.commandpub.publish(cmd)
										cmd = cmd + "done"
										while self.command != cmd and not rospy.is_shutdown():
											rospy.sleep(1)
										self.pickFromzero(armno,producttype,productpos)
										rospy.sleep(delay)
										# print("................. Pick from Zero .................. ")
										self.turnToBin(armno)
										rospy.sleep(delay)
										# print("................. Turn to Bin .................. ")
										self.turnToAGV(armno,armno)
										rospy.sleep(delay)
										# print("................. Turn to AGV .................. ")
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										self.moveWristBin(armno)
										rospy.sleep(delay)
										# print("................. Move Wrist to Bin .................. ")
										gtraypose = self.placeToTray(armno,productpos,armno)
										rospy.sleep(delay)
										# print("................. Place to Tray .................. ")
										ariac_example.control_gripper(False, armno)
										rospy.sleep(delay)
										# print("................. Controller .................. ")
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										# print("................. Go to AGV .................. ")
										ariac_example.control_gripper(True, armno)
										rospy.sleep(delay)
										# print("................. Control Gripper .................. ")
										self.moveWristBin(armno)
										rospy.sleep(delay)
										# print("................. Wrist Movement to Bin for Orientation Control .................. ")
										self.setorientation(armno,gtraypose,producttype)
										rospy.sleep(delay)
										ariac_example.control_gripper(False, armno)
										rospy.sleep(delay)
										# rospy.sleep(armno)
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										self.command=""
									
									flag = True
									break
							if flag:
								break

					if not flag:
						# the model is not available in static bin
						# pick from belt
						if self.beltModels and armno==1:
							for model in self.beltModels:
								if model.type == producttype:
									pose = model.pose
									ariac_example.control_gripper(True, armno)
									self.turnToBelt(armno)
									rospy.sleep(delay)
									self.goToAGVOnlyY(armno,armno)
									rospy.sleep(delay)

									self.pickFromCamera(armno,pose,producttype)

									rospy.sleep(delay)
									self.turnToBelt(armno)
									self.beltStop = False
									rospy.sleep(delay)
									self.turnToAGV(armno,armno)
									rospy.sleep(delay)
									self.goToAGV(armno,armno)
									rospy.sleep(delay)
									self.moveWristBin(armno)
									gtraypose = self.placeToTray(armno,productpos,armno,initPose=pose)
									ariac_example.control_gripper(False, armno)
									self.goToAGV(armno,armno)
									ariac_example.control_gripper(True, armno)
									self.moveWristBin(armno)
									self.setorientation(armno,gtraypose,producttype)
									ariac_example.control_gripper(False, armno)
									rospy.sleep(1)
									self.goToAGV(armno,armno)
									
						elif armno==2:
							cmd = "frombelt"+str(armno)+" "+producttype
							self.commandpub.publish(cmd)
							cmd = cmd + "done"
							while self.command != cmd and not rospy.is_shutdown():
								rospy.sleep(1)
							self.pickFromzero(armno,producttype,productpos)
							rospy.sleep(delay)
							# print("................. Pick from Zero .................. ")
							self.turnToBin(armno)
							rospy.sleep(delay)
							# print("................. Turn to Bin .................. ")
							self.turnToAGV(armno,armno)
							rospy.sleep(delay)
							# print("................. Turn to AGV .................. ")
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							self.moveWristBin(armno)
							rospy.sleep(delay)
							# print("................. Move Wrist to Bin .................. ")
							gtraypose = self.placeToTray(armno,productpos,armno)
							rospy.sleep(delay)
							# print("................. Place to Tray .................. ")
							ariac_example.control_gripper(False, armno)
							rospy.sleep(delay)
							# print("................. Controller .................. ")
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							# print("................. Go to AGV .................. ")
							ariac_example.control_gripper(True, armno)
							rospy.sleep(delay)
							# print("................. Control Gripper .................. ")
							self.moveWristBin(armno)
							rospy.sleep(delay)
							# print("................. Wrist Movement to Bin for Orientation Control .................. ")
							self.setorientation(armno,gtraypose,producttype)
							rospy.sleep(delay)
							ariac_example.control_gripper(False, armno)
							rospy.sleep(delay)
							# rospy.sleep(armno)
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							self.command=""
						else:
							# ariac_example.start_belt()
							return
							
				ariac_example.control_agv(shipment.shipment_type, armno)
				print("*********************shipment  complete*****************************",armno)
			del self.received_orders[0]
			cmd = "arm1 not working"
			self.commandpub.publish(cmd)
			print("order complete")
			return

	def checkOrder(self,armno=1):
		self.gotoHome(armno)
		if armno==1:
			ariac_example.start_competition()
		# rospy.sleep(1)
		# ariac_example.stop_belt()
		rate = rospy.Rate(1.0)
		while not rospy.is_shutdown():
			# if armno == 1:
			self.pick_place(armno)

			if armno==1 and "puttozero2" in self.command and not ("done" in self.command):	
				producttype = self.command[11:]
				self.putTozeroCheck(armno,producttype,self.command)
				self.command=""
				print(producttype)

			if armno==1 and "frombelt2" in self.command and not ("done" in self.command):	
				producttype = self.command[10:]
				self.putTozeroFrombelt(armno,producttype,self.command)
				self.command=""
				print(producttype)

			if armno==2 and ("puttozero1" in self.command) and not ("done" in self.command):	
				producttype = self.command[11:]
				self.putTozeroCheck(armno,producttype,self.command)
				self.command=""
				print(producttype)
					
			rate.sleep()

				
