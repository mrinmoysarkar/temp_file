#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt,pi,atan2,cos,sin
from osrf_gear.msg import Proximity
from osrf_gear.msg import LogicalCameraImage
from osrf_gear.msg import Order
from osrf_gear.msg import VacuumGripperState
import time
from std_msgs.msg import String
from rosgraph_msgs.msg import Clock




class ArmController():
	def __init__(self,ns,armno):
		self.debug=False
		self.delay=1.0

		rospy.init_node('ariac_competetion_solution_node'+str(armno), anonymous=True)
		rospy.sleep(2*self.delay)

		moveit_commander.roscpp_initialize(sys.argv)
		self.robot = moveit_commander.RobotCommander(robot_description=ns+"/robot_description",ns=ns)
		self.scene = moveit_commander.PlanningSceneInterface(ns=ns)
		self.group_name = "manipulator"
		self.move_group = moveit_commander.MoveGroupCommander(self.group_name,robot_description=ns+"/robot_description",ns=ns)
		
		
		self.pickFlag = False
		self.modelsaveFlag = [True]*9
		self.models = {}
		self.beltModels=[]
		self.lastBeltModel = None
		self.received_orders = []
		self.cameraypose = [1.9135,1.1499,0.383,-0.383,-1.1504,-1.9135]
		self.attachth={"gasket_part":0.03,"piston_rod_part":0.01,"pulley_part":0.07,"gear_part":0.03,"disk_part":0.035}
		self.attachthbelt={"gasket_part":0.03,"piston_rod_part":0.01,"pulley_part":0.1,"gear_part":0.03,"disk_part":0.035}
		# self.attachth={"gasket_part":0.035,"piston_rod_part":0.015,"pulley_part":0.075,"gear_part":0.035,"disk_part":0.035}

		self.traymodels = []
		self.gripperState = False
		self.zeropointModels = []

		
		self.tfBuffer = tf2_ros.Buffer()
		self.listener = tf2_ros.TransformListener(self.tfBuffer)
		self.command = ""
		self.armnoWorking = "default"
		self.beltStop = False
		self.beltz = 0
		self.armno = armno
		self.shipmenttype = ""
		self.simtime = 0
		self.starttime = 0
		self.simtimeCheck = True

		self.order_update = False
		self.competetionstate = ""
		self.flipwillbechecked = True
		

		
		rospy.Subscriber('/clock',Clock,self.simClockCallback)
		rospy.Subscriber('/ariac/competition_state',String,self.competitionStaceCallback)
		
		
		rospy.Subscriber('/ariac/logical_camera_4',LogicalCameraImage,self.logicalCamera4Callback)
		rospy.Subscriber('/ariac/logical_camera_5',LogicalCameraImage,self.logicalCamera5Callback)
		rospy.Subscriber('/ariac/logical_camera_6',LogicalCameraImage,self.logicalCamera6Callback)
		rospy.Subscriber('/ariac/logical_camera_7',LogicalCameraImage,self.logicalCamera7Callback)
		rospy.Subscriber('/ariac/logical_camera_8',LogicalCameraImage,self.logicalCamera8Callback)
		rospy.Subscriber('/ariac/logical_camera_9',LogicalCameraImage,self.logicalCamera9Callback)
		rospy.Subscriber('/ariac/logical_camera_11',LogicalCameraImage,self.logicalCamera11Callback)
		if armno == 1:
			self.commandpub = rospy.Publisher('/slavecommand1', String, queue_size=10)
			rospy.Subscriber('/slavecommand2', String, self.commmandCallback)

			rospy.Subscriber('/ariac/arm1/gripper/state',VacuumGripperState,self.gripperStateCAllback)
			rospy.Subscriber('/ariac/logical_camera_1',LogicalCameraImage,self.logicalCamera1Callback)
			rospy.Subscriber("/ariac/break_beam_1_change",Proximity,self.breakbeam1Callback)
			rospy.Subscriber('/ariac/logical_camera_3',LogicalCameraImage,self.logicalCamera3Callback)
			rospy.Subscriber("/ariac/break_beam_2_change",Proximity,self.breakbeam2Callback)
		elif armno == 2:
			self.commandpub = rospy.Publisher('/slavecommand2', String, queue_size=10)
			rospy.Subscriber('/slavecommand1', String, self.commmandCallback)

			rospy.Subscriber('/ariac/arm2/gripper/state',VacuumGripperState,self.gripperStateCAllback)
			rospy.Subscriber('/ariac/logical_camera_2',LogicalCameraImage,self.logicalCamera2Callback)
			rospy.Subscriber("/ariac/break_beam_3_change",Proximity,self.breakbeam3Callback)
			rospy.Subscriber('/ariac/logical_camera_10',LogicalCameraImage,self.logicalCamera10Callback)
			rospy.Subscriber("/ariac/break_beam_4_change",Proximity,self.breakbeam4Callback)

		rospy.Subscriber("/ariac/orders", Order, self.order_callback)
		rospy.sleep(2*self.delay)

	def commmandCallback(self,msg):
		self.command = msg.data
		if "working" in msg.data:
			self.armnoWorking = msg.data
		if self.debug:
			print(msg,self.armno)

	def competitionStaceCallback(self,msg):
		if self.competetionstate != msg.data:
			self.competetionstate = msg.data
			if self.debug:
				print("***************************** competition state: " + msg.data + " *****************************",self.armno)

	def simClockCallback(self,msg):
		self.simtime = msg.clock.secs
		if (self.simtime - self.starttime) >= 497 and len(self.traymodels)>0 and self.simtimeCheck and len(self.shipmenttype)>0:
			if self.debug:
				print("simulation over",self.armno)
			# ariac_example.control_gripper(False, self.armno)
			# self.gotoHome(self.armno)
			ariac_example.control_agv(self.shipmenttype, self.armno)
			# self.traymodels = []
			self.simtimeCheck = False
				
	def gripperStateCAllback(self,msg):
		self.gripperState = msg.attached

	def order_callback(self, msg):
		if self.debug:
			print(msg,self.armno)
		if self.received_orders and len(self.received_orders)>0:
			for i in range(len(self.received_orders)):
				if (msg.order_id in self.received_orders[i].order_id) or (self.received_orders[i].order_id in msg.order_id):
					self.received_orders[i]=msg
					self.order_update = True
					return
		self.received_orders.append(msg)

	def breakbeam1Callback(self,msg):
		if msg.object_detected and self.pickFlag:
			if self.debug:
				print("one object found",self.armno)
			start_pose = self.move_group.get_current_pose().pose
			start_pose.position.z = self.beltz 

			if self.debug:
				print("debug 1",self.armno)
			
			try:
				self.move_group.set_pose_target(start_pose)
				self.move_group.go(wait=True)
			except Exception as e:
				if self.debug:
					print(e,self.armno)
			self.move_group.stop()
			self.move_group.clear_pose_targets()
			rospy.sleep(1*self.delay)
			joint_goal = self.move_group.get_current_joint_values()
		
			joint_goal[2] = -pi/2 # shoulder_lift_joint
			

			try:
				self.move_group.go(joint_goal, wait=True)
			except Exception as e:
				if self.debug:
					print(e,self.armno)
			self.move_group.stop()
			self.move_group.clear_pose_targets()
			rospy.sleep(2*self.delay)
			self.pickFlag = False
		elif msg.object_detected and self.beltModels and len(self.beltModels) > 0:
			del self.beltModels[0]
		
	def breakbeam2Callback(self,msg):
		if msg.object_detected:
			self.beltModels.append(self.lastBeltModel)
			# print("no of object in belt :::::************************",len(self.beltModels))

	def breakbeam4Callback(self,msg):
		if msg.object_detected:
			self.beltModels.append(self.lastBeltModel)
			# print("no of object in belt :::::************************",len(self.beltModels))

	def breakbeam3Callback(self,msg):
		if msg.object_detected and self.pickFlag:
			# print("one object found")
			start_pose = self.move_group.get_current_pose().pose
			start_pose.position.z = self.beltz 
			
			if self.debug:
				print("debug 2",self.armno)

			try:
				self.move_group.set_pose_target(start_pose)
				self.move_group.go(wait=True)
			except Exception as e:
				if self.debug:
					print(e,self.armno)
			self.move_group.stop()
			self.move_group.clear_pose_targets()
			rospy.sleep(1*self.delay)
			joint_goal = self.move_group.get_current_joint_values()
		
			joint_goal[2] = -pi/2 # shoulder_lift_joint
			

			try:
				self.move_group.go(joint_goal, wait=True)
			except Exception as e:
				if self.debug:
					print(e,self.armno)
			self.move_group.stop()
			self.move_group.clear_pose_targets()
			rospy.sleep(2*self.delay)
			self.pickFlag = False
		elif msg.object_detected and self.beltModels and len(self.beltModels) > 0:
			del self.beltModels[0]

	def logicalCamera11Callback(self,msg):
		models = msg.models #it is a list
		self.zeropointModels = []
		if models:
			frame = 'logical_camera_11_frame' 
			for model in models:
				pose = model.pose
				gpose = self.getglobalpose(frame,pose)
				model.pose = gpose.pose
				self.zeropointModels.append(model)

	def logicalCamera3Callback(self,msg):
		models = msg.models #it is a list
		if models:
			frame = 'logical_camera_3_frame' 
			self.lastBeltModel = models[0]
			pose=self.lastBeltModel.pose
			gpose=self.getglobalpose(frame,pose)
			self.lastBeltModel.pose = gpose.pose

	def logicalCamera10Callback(self,msg):
		models = msg.models #it is a list
		if models:
			frame = 'logical_camera_10_frame' 
			self.lastBeltModel = models[0]
			pose=self.lastBeltModel.pose
			gpose=self.getglobalpose(frame,pose)
			self.lastBeltModel.pose = gpose.pose
		
	def logicalCamera1Callback(self,msg):
		self.traymodels = msg.models #it is a list
		# print(self.traymodels)		

	def logicalCamera2Callback(self,msg):
		self.traymodels = msg.models #it is a list
		# print(self.traymodels)

	def logicalCamera4Callback(self,msg):
		if self.modelsaveFlag[3]:
			models = msg.models #it is a list
			self.models['logicalCamera4']=[]
			if models:
				frame = 'logical_camera_4_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera4' in self.models:
						self.models['logicalCamera4'] = [model]
					else:
						self.models['logicalCamera4'].append(model)
			self.modelsaveFlag[3] = False
				
	def logicalCamera5Callback(self,msg):
		if self.modelsaveFlag[4]:
			models = msg.models #it is a list
			self.models['logicalCamera5']=[]
			if models:
				frame = 'logical_camera_5_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera5' in self.models:
						self.models['logicalCamera5'] = [model]
					else:
						self.models['logicalCamera5'].append(model)
			self.modelsaveFlag[4] = False
				
	def logicalCamera6Callback(self,msg):
		if self.modelsaveFlag[5]:
			models = msg.models #it is a list
			self.models['logicalCamera6']=[]
			if models:
				frame = 'logical_camera_6_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera6' in self.models:
						self.models['logicalCamera6'] = [model]
					else:
						self.models['logicalCamera6'].append(model)
			self.modelsaveFlag[5] = False
				
	def logicalCamera7Callback(self,msg):
		if self.modelsaveFlag[6]:
			models = msg.models #it is a list
			self.models['logicalCamera7']=[]
			if models:
				frame = 'logical_camera_7_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera7' in self.models:
						self.models['logicalCamera7'] = [model]
					else:
						self.models['logicalCamera7'].append(model)
			self.modelsaveFlag[6] = False			

	def logicalCamera8Callback(self,msg):
		if self.modelsaveFlag[7]:
			models = msg.models #it is a list
			self.models['logicalCamera8']=[]
			if models:
				frame = 'logical_camera_8_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera8' in self.models:
						self.models['logicalCamera8'] = [model]
					else:
						self.models['logicalCamera8'].append(model)
			self.modelsaveFlag[7] = False			

	def logicalCamera9Callback(self,msg):
		if self.modelsaveFlag[8]:
			models = msg.models #it is a list
			self.models['logicalCamera9']=[]
			if models:
				frame = 'logical_camera_9_frame' 
				
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					model.pose = gpose.pose
					if not 'logicalCamera9' in self.models:
						self.models['logicalCamera9'] = [model]
					else:
						self.models['logicalCamera9'].append(model)
			self.modelsaveFlag[8] = False
						
	def gotoHome(self,armno):
		# self.move_group.set_named_target("home")
		# self.move_group.set_named_target("up")
		# print(self.move_group.go(wait=True))

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		if armno==1:
			joint_goal[0] = 1.18 # linear_arm_actuator_joint
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==2:
			joint_goal[0] = -1.18 # linear_arm_actuator_joint
			joint_goal[1] = 3*pi/2 # shoulder_pan_join
		
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = pi/4 # elbow_joint 
		
		joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		joint_goal[5] = 0 #wrist_2_joint
		joint_goal[6] = 0 # wrist_3_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		rospy.sleep(1*self.delay)
		# self.move_group.stop()
	
	def turnToAGV(self,armno,agvno):
		joint_goal = self.move_group.get_current_joint_values()
		if agvno==1:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def goToAGV(self,armno,agvno):

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		
		if agvno==1:
			joint_goal[0] = 1.15 # linear_arm_actuator_joint
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif agvno==2:
			joint_goal[0] = -1.15 # linear_arm_actuator_joint
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 
		

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def goToAGVOnlyY(self,armno,agvno):
		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		
		if agvno==1:
			joint_goal[0] = 1.15 # linear_arm_actuator_joint
			
		elif agvno==2:
			joint_goal[0] = -1.15 # linear_arm_actuator_joint
		
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def turnToBelt(self,armno):
		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[1] = 0 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = 3*pi/4 # elbow_joint 

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def turnToBin(self,armno,option=0):
		joint_goal = self.move_group.get_current_joint_values()
		# if armno==1:
		joint_goal[1] = pi # shoulder_pan_joint
		# elif armno==2:
		# 	joint_goal[1] = 3*pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		if option == 1:
			joint_goal[3] = 2.3*pi/4 # elbow_joint 
		else:
			joint_goal[3] = 3*pi/4 # elbow_joint 

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def goToCamera(self,armno,camerano,option=0):
		line_joint = 0
		
		if armno==1 and abs(min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==2 and abs(min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)) == 1.18:
			return False
		elif armno==1:
			line_joint = min(max(self.cameraypose[camerano-4] - 0.920057,-1.18),1.18)
		elif armno==2:
			line_joint = min(max(self.cameraypose[camerano-4] + 0.920057,-1.18),1.18)

		if armno==1 and option==1:
			line_joint += 0.1
		elif armno==2 and option==1:
			line_joint -= 0.1
		elif armno==1 and option==2:
			line_joint += 0.25
		elif armno==2 and option==2:
			line_joint -= 0.25

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = line_joint 
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		return True
		
	def pickFromCamera(self,armno,pose,type):
		if self.debug:
			print(type,self.armno)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = pose.position.x
		start_pose.position.y = pose.position.y
		start_pose.position.z = pose.position.z+0.1#self.attachth[type]
		
		if self.debug:
			print("debug 3",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = pose.position.x
		start_pose.position.y = pose.position.y
		start_pose.position.z = pose.position.z+self.attachth[type]

		if self.debug:
			print("debug 4",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		if self.debug:
			print("**********gripperstate:********  ",self.gripperState,self.armno)

		self.attachcheck()
		
	def attachcheck(self):
		starttime = time.time()
		while not self.gripperState and not rospy.is_shutdown():
			joint_goal = self.move_group.get_current_joint_values()
			desired_angle = 3*pi/2+0.1 -(joint_goal[2]+joint_goal[3])
			joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
			if self.debug:
				print("debug 5",self.armno)

			try:
				self.move_group.go(joint_goal,wait=True)
			except Exception as e:
				if self.debug:
					print(e,self.armno)
			self.move_group.stop()
			self.move_group.clear_pose_targets()
			rospy.sleep(1*self.delay)
			if (time.time() - starttime )> 10:
				break

	def placeToTray(self,armno,pose,kitTrayno,initPose=None):
		if kitTrayno == 1:
			frame = 'kit_tray_1'
		else:
			frame = 'kit_tray_2'
		
		gpose = self.getglobalpose(frame,pose)
		
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = gpose.pose.position.x
		if armno==1:
			start_pose.position.y = gpose.pose.position.y
		elif armno==2:
			start_pose.position.y = gpose.pose.position.y

		start_pose.position.z = gpose.pose.position.z+0.17

		if self.debug:
			print("debug 6",self.armno)

		
		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		self.moveWristBin(armno)
		return gpose.pose

	def setorientation(self,armno,pose,type):
		count_traymodel = 0
		while True:
			if self.traymodels:
				mind = 10e10
				minpose=None
				for model in self.traymodels:
					if model.type != type:
						continue
					if armno==1:
						frame = 'logical_camera_1_frame'
					elif armno==2:
						frame = 'logical_camera_2_frame'
					globalpose = self.getglobalpose(frame,model.pose)
					d = self.getdistance(pose,globalpose.pose)
					if d<mind:
						mind = d
						minpose = globalpose.pose
				if minpose == None:
					return

				if minpose != None:
					joint_goal = self.move_group.get_current_joint_values()
					joint_goal[6] = 0 
					if self.debug:
						print(joint_goal[6],self.armno)
					try:
						self.move_group.go(joint_goal, wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					rospy.sleep(1*self.delay)
					self.moveWristBin(armno)
					start_pose = self.move_group.get_current_pose().pose
					start_pose.position.x = minpose.position.x
					start_pose.position.y = minpose.position.y
					start_pose.position.z = minpose.position.z+0.1
					
					if self.debug:
						print("debug 7",self.armno)

					try:
						self.move_group.set_pose_target(start_pose)
						self.move_group.go(wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					rospy.sleep(1*self.delay)
					rpy1 = self.getrpy(pose)
					start_pose = self.move_group.get_current_pose().pose
					start_pose.position.x = minpose.position.x
					start_pose.position.y = minpose.position.y
					if rpy1[0] != 0:
						start_pose.position.z = minpose.position.z
					else:
						start_pose.position.z = minpose.position.z+self.attachth[type]
					
					if self.debug:
						print("debug 8",self.armno)

					try:
						self.move_group.set_pose_target(start_pose)
						self.move_group.go(wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					rospy.sleep(1*self.delay)
					self.attachcheck()

					self.moveWristBin(armno)
					start_pose = self.move_group.get_current_pose().pose
					start_pose.position.x = minpose.position.x
					start_pose.position.y = minpose.position.y
					start_pose.position.z = minpose.position.z+0.15
					
					if self.debug:
						print("debug 9",self.armno)

					try:
						self.move_group.set_pose_target(start_pose)
						self.move_group.go(wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					self.moveWristBin(armno)
					rpy1 = self.getrpy(pose)
					rpy2 = self.getrpy(minpose)
					
					joint_goal = self.move_group.get_current_joint_values()
					joint_goal[6] -= rpy1[2]-rpy2[2] 
					try:
						self.move_group.go(joint_goal, wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					rospy.sleep(1*self.delay)

					start_pose = self.move_group.get_current_pose().pose
					start_pose.position.x = pose.position.x
					start_pose.position.y = pose.position.y
					start_pose.position.z = pose.position.z+0.17
					

					if self.debug:
						print("debug 10",self.armno)

					try:
						self.move_group.set_pose_target(start_pose)
						self.move_group.go(wait=True)
					except Exception as e:
						if self.debug:
							print(e,self.armno)
					self.move_group.stop()
					self.move_group.clear_pose_targets()
					rospy.sleep(1*self.delay)
				break
			rospy.sleep(1*self.delay)
			count_traymodel += 1
			if count_traymodel > 5:
				return
		
	def getdistance(self,pose1,pose2):
		d=(pose1.position.x-pose2.position.x)**2
		d+=(pose1.position.y-pose2.position.y)**2
		d+=(pose1.position.z-pose2.position.z)**2
		return d

	def moveWristBin(self,armno,enable=False):
		joint_goal = self.move_group.get_current_joint_values()
		desired_angle = 3*pi/2-(joint_goal[2]+joint_goal[3])
		joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		if self.debug:
			print("debug 20",self.armno)
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		if self.debug:
			print("debug 21",self.armno)
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def gotoBreakbeam(self,armno):
		if armno==1:
			y = 0.9
		elif armno==2:
			y = -1.1

		joint_goal = self.move_group.get_current_joint_values()
		# print('joint gole',joint_goal)
		
		joint_goal[0] = y# linear_arm_actuator_joint
			
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

	def alignHandforPickFromBelt(self,armno,producttype):
		while True:
			flag = False
			if self.beltModels and len(self.beltModels)>0:
				for i in range(len(self.beltModels)):
					model = self.beltModels[i]
					if self.debug:
						print("model of belts ***** ",model,self.armno)
					if model != None and model.type == producttype:
						x = model.pose.position.x
						self.beltz = model.pose.position.z + self.attachth[producttype]
						flag = True
						del self.beltModels[i]
						break
			if flag:
				break
			rospy.sleep(1*self.delay)

		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = x
		if armno==1:
			start_pose.position.y = 1.97
		elif armno==2:
			start_pose.position.y = -2.03

		if producttype == "pulley_part":
			start_pose.position.z = 1.12
		else:
			start_pose.position.z = 1.0

		if self.debug:
			print("debug 15",self.armno)	

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		self.pickFlag = True

	def getrpy(self,pose):
		quaternion = (
		pose.orientation.x,
		pose.orientation.y,
		pose.orientation.z,
		pose.orientation.w)
		euler = tf.transformations.euler_from_quaternion(quaternion)
		roll = euler[0]
		pitch = euler[1]
		yaw = euler[2]
		return euler

	def getglobalpose(self,frame,pose,frame2="none"):
		while not rospy.is_shutdown():
			try:
				if frame2=="none":
					trans = self.tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, 'world')
					return world_pose	
				else:
					trans = self.tfBuffer.lookup_transform(frame2, frame, rospy.Time(), rospy.Duration(1.0))
					
					local_pose = geometry_msgs.msg.PoseStamped()
					local_pose.header.frame_id = frame
					local_pose.pose=pose

					world_pose = self.tfBuffer.transform(local_pose, frame2)
					return world_pose

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				if self.debug:
					print(e,self.armno)
				continue

	def putToZero(self,armno):
		joint_goal = self.move_group.get_current_joint_values()
		if armno==2:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==1:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 1.177
		
		if self.debug:
			print("debug 16",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		self.moveWristBin(armno)
		ariac_example.control_gripper(False, armno)
		rospy.sleep(1*self.delay)	

	def putToZeroFlip(self,armno):
		joint_goal = self.move_group.get_current_joint_values()
		if armno==2:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==1:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		start_pose.position.z = 1.177
		
		if self.debug:
			print("debug 16",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		self.moveWristBin(armno)
		rospy.sleep(1*self.delay)
		joint_goal = self.move_group.get_current_joint_values()
		joint_goal[5] += (-pi/2+(pi)- joint_goal[5]) #wrist_2_joint
		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)

		ariac_example.control_gripper(False, armno)
		rospy.sleep(1*self.delay)	

	def putTozeroCheck(self,armno,producttype,option=0):
		for i in range(6):
			self.modelsaveFlag[3+i]=True

		while True:
			flg = True
			for i in range(6):
				if self.modelsaveFlag[3+i]:
					flg = False
					break
			if flg:
				break
			rospy.sleep(1*self.delay)

		if self.models:
			keys = self.models.keys()
			for key in keys:
				allModels = self.models[key]
				flag = False
				indx = -1
				for model in allModels:
					# print(model)
					indx = indx + 1
					if model.type == producttype:
						camerano = int(key[-1])
						pose = model.pose
						if self.debug:
							print(camerano,self.armno)
						self.turnToBin(armno)
						if self.goToCamera(armno,camerano):
							# del self.models[key][indx]
							if self.debug:
								print('arm',armno,' can pick',self.armno)
							ariac_example.control_gripper(True, armno)
							rospy.sleep(2*self.delay)
							self.moveWristBin(armno)
							self.pickFromCamera(armno,pose,producttype)
							self.moveWristBin(armno)
							self.turnToBin(armno)
							if armno == 1:
								self.goToCamera(armno,6)
							else:
								self.goToCamera(armno,7)
							if option==1:
								self.putToZeroFlip(armno)
							else:
								self.putToZero(armno)
								self.turnToAGV(armno,armno)
							rospy.sleep(1*self.delay)
							if self.debug:
								print("zero models: ", self.zeropointModels,self.armno)
							for model in self.zeropointModels:
								if model.type == producttype:
									self.commandpub.publish("done")
									if option==1:
										# wait for response
										while self.command != "turntobin":
											rospy.sleep(1*self.delay)
										self.command = ""
										self.turnToBin(armno)
									return								
							self.putTozeroCheck(armno,producttype,option=option)

	def putTozeroCheckself(self,armno,producttype,option=0):
		for i in range(6):
			self.modelsaveFlag[3+i]=True

		while True:
			flg = True
			for i in range(6):
				if self.modelsaveFlag[3+i]:
					flg = False
					break
			if flg:
				break
			rospy.sleep(1*self.delay)

		if self.models:	
			keys = self.models.keys()
			for key in keys:
				allModels = self.models[key]
				flag = False
				indx = -1
				for model in allModels:
					# print(model)
					indx = indx + 1
					if model.type == producttype:
						camerano = int(key[-1])
						pose = model.pose
						if self.debug:
							print(camerano,self.armno)
						self.turnToBin(armno)
						if self.goToCamera(armno,camerano):
							# del self.models[key][indx]
							if self.debug:
								print('arm',armno,' can pick',self.armno)
							ariac_example.control_gripper(True, armno)
							self.moveWristBin(armno)
							self.pickFromCamera(armno,pose,producttype)
							self.moveWristBin(armno)
							self.turnToBin(armno)
							if armno == 1:
								self.goToCamera(armno,6)
							else:
								self.goToCamera(armno,7)
							if option==1:
								self.putToZeroFlip(armno)
							else:
								self.putToZero(armno)
								self.turnToAGV(armno,armno)
							rospy.sleep(1*self.delay)
							if self.debug:
								print("zero models: ", self.zeropointModels,self.armno)
							for model in self.zeropointModels:
								if model.type == producttype:
									self.commandpub.publish("grab_and_place")
									if option==1:
										# wait for response
										while self.command != "turntobin":
											rospy.sleep(1*self.delay)
										self.command = ""
										self.turnToBin(armno)
									return								
							self.putTozeroCheck(armno,producttype,option=option)

	def pickFromzero(self,armno,producttype,productpos=None,option=0):
		joint_goal = self.move_group.get_current_joint_values()
		if armno==2:
			joint_goal[1] = pi/2 # shoulder_pan_joint
		elif armno==1:
			joint_goal[1] = 3*pi/2 # shoulder_pan_joint

		try:
			self.move_group.go(joint_goal, wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		if armno == 1:
			self.goToCamera(armno,6,option=option)
		else:
			self.goToCamera(armno,7,option=option)
		# print(".................Go to Position .................. ")
		ariac_example.control_gripper(True, armno)
		rospy.sleep(1*self.delay)
		start_pose = self.move_group.get_current_pose().pose
		start_pose.position.x = 0.3
		start_pose.position.y = 0
		if option==1:
			start_pose.position.z = 1.45
		else:
			start_pose.position.z = 1.15
		
		if self.debug:
			print("debug 17",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		self.moveWristBin(armno)
		rospy.sleep(1*self.delay)
		# print(".................Pick the object.................. ")
		start_pose = self.move_group.get_current_pose().pose
		# start_pose.position.x = 0.3
		# start_pose.position.y = 0
		# start_pose.position.z = 0.943+self.attachth[producttype]
		if len(self.zeropointModels)>0:
			start_pose.position.x = self.zeropointModels[0].pose.position.x
			start_pose.position.y = self.zeropointModels[0].pose.position.y
		
		if option==1:
			start_pose.position.z = 1.305 + self.attachth[producttype]
		else:
			start_pose.position.z = 0.943 + self.attachth[producttype]
		
		if self.debug:
			print("debug 18",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		self.moveWristBin(armno)
		rospy.sleep(1*self.delay)
		# print(".................Up the Object .................. ")
		start_pose = self.move_group.get_current_pose().pose
		# start_pose.position.x = 0.3
		# start_pose.position.y = 0
		if option==1:
			start_pose.position.z = 1.45
		else:
			start_pose.position.z = 1.15
		
		if self.debug:
			print("debug 19",self.armno)

		try:
			self.move_group.set_pose_target(start_pose)
			self.move_group.go(wait=True)
		except Exception as e:
			if self.debug:
				print(e,self.armno)
		self.move_group.stop()
		self.move_group.clear_pose_targets()
		rospy.sleep(1*self.delay)
		# print("................. Turn to the object .................. ")
		self.attachcheck()

	def pickfromzerocheck(self,armno,producttype,productpos,option=0):
		self.turnToBin(armno,option=option)
		self.moveWristBin(armno)
		self.pickFromzero(armno,producttype,productpos,option=option)
		self.turnToBin(armno)
		if option==1:
			self.commandpub.publish("turntobin")
		self.turnToAGV(armno,armno)
		self.goToAGV(armno,armno)
		self.moveWristBin(armno)
		gtraypose = self.placeToTray(armno,productpos,armno)
		ariac_example.control_gripper(False, armno)
		self.goToAGV(armno,armno)
		ariac_example.control_gripper(True, armno)
		self.moveWristBin(armno)
		self.setorientation(armno,gtraypose,producttype)
		ariac_example.control_gripper(False, armno)
		self.goToAGV(armno,armno)
		rospy.sleep(1*self.delay)

	def getModelLocation(self,armno,producttype,passno):
		for i in range(6):
			self.modelsaveFlag[3+i]=True

		while True:
			flg = True
			for i in range(6):
				if self.modelsaveFlag[3+i]:
					flg = False
					break
			if flg:
				break
			rospy.sleep(1*self.delay)

		if self.models:
			keys = self.models.keys()
			helpFlag = False
			for key in keys:
				allModels = self.models[key]
				indx = -1
				for model in allModels:
					# print(model)
					indx = indx + 1
					if model.type == producttype:
						helpFlag = True
						if passno == 0:
							return True,'pass0',0,0

						camerano = int(key[-1])
						pose = model.pose
						self.turnToBin(armno)
						rospy.sleep(2*self.delay)
						if self.debug:
							print("camera no", camerano,self.armno)
						if self.goToCamera(armno,camerano):
							rospy.sleep(1*self.delay)
							return True,pose,key,indx
						break
			if helpFlag:
				return False,'need help',0,0
		return False,'belt',0,0

	def grab_and_place(self,armno):
		option=1
		self.turnToBin(armno,option=option)
		self.moveWristBin(armno)
		if armno == 1:
			self.goToCamera(armno,6,option=2)
		else:
			self.goToCamera(armno,7,option=2)
		self.pickFromzero(armno,"pulley_part",option=option)
		self.turnToBin(armno)
		self.commandpub.publish("turntobin")
		while self.command != "turntobindone":
			rospy.sleep(1*self.delay)
		self.command = ""
		self.putToZero(armno)
		self.turnToBin(armno)
		self.commandpub.publish("grabdone")
		rospy.sleep(1*self.delay)

	def checkwithTrayModels(self,type,pose):
		if len(self.traymodels) > 0:
			for model in self.traymodels:
				if model.type == type:
					d = self.getdistance(pose,model.pose)
					if self.debug:
						print("d*************",d,self.armno)
					if d < 0.9:
						return True

		return False

	def sortproducts(self,products):
		newproductlist=[]
		flipproductlist=[]
		for product in products:
			rpy = self.getrpy(product.pose)
			if rpy[0] != 0:
				flipproductlist.append(product)
			else:
				newproductlist.append(product)

		return list(newproductlist+flipproductlist)

	def ship(self,products,armno,shipmentType):
		self.shipmenttype = shipmentType
		passno = 0
		allflags = [False]*len(products)
		countoftry = [0]*len(products)
		products = self.sortproducts(products)
		for i in range(len(allflags)):
			allflags[i] = self.checkwithTrayModels(products[i].type,products[i].pose)

		arm1doneflag = False
		while True and not rospy.is_shutdown():
			alltrue = True
			for i in range(len(products)):
				if self.order_update:
					return
				if not allflags[i]:
					alltrue = False
					product = products[i]
					producttype = product.type
					productpos = product.pose
					rpy = self.getrpy(productpos)
					flag,info,key,indx = self.getModelLocation(armno,producttype,passno)
					if info=='belt':
						# pick from belt
						if self.debug:
							print("pick: belt ", self.armno, producttype,passno)
						

						ariac_example.control_gripper(True, armno)
						rospy.sleep(1*self.delay)
						self.turnToBelt(armno)
						self.gotoBreakbeam(armno)
						self.moveWristBin(armno)
						self.alignHandforPickFromBelt(armno,producttype)
						while self.pickFlag:
							rospy.sleep(0.1*self.delay)
						self.turnToBelt(armno)

						self.turnToAGV(armno,armno)
						self.goToAGV(armno,armno)
						self.moveWristBin(armno)
						gtraypose = self.placeToTray(armno,productpos,armno)
						ariac_example.control_gripper(False, armno)
						self.goToAGV(armno,armno)
						ariac_example.control_gripper(True, armno)
						self.moveWristBin(armno)
						self.setorientation(armno,gtraypose,producttype)
						ariac_example.control_gripper(False, armno)
						rospy.sleep(1*self.delay)
						self.goToAGV(armno,armno)

						allflags[i] = self.checkwithTrayModels(producttype,productpos)
						countoftry[i] += 1
						if countoftry[i] == 2:
							allflags[i] = True

					elif flag and passno != 0:
						if self.debug:
							print("pick: ",self.armno, producttype,passno)
						pose = info
						# del self.models[key][indx]
						
						ariac_example.control_gripper(True, armno)
						rospy.sleep(1*self.delay)
						self.moveWristBin(armno)
						self.pickFromCamera(armno,pose,producttype)
						self.moveWristBin(armno)
						self.turnToBin(armno)
						if rpy[0] != 0 and self.flipwillbechecked:
							if armno == 1:
								self.goToCamera(armno,6)
							else:
								self.goToCamera(armno,7)
							self.putToZeroFlip(armno)
							self.commandpub.publish("grab_and_place")
							while self.command != "turntobin":
								rospy.sleep(1*self.delay)
							self.command = ""
							self.turnToBin(armno)
							self.moveWristBin(armno)
							self.commandpub.publish("turntobindone")
							while self.command != "grabdone":
								rospy.sleep(1*self.delay)
							self.pickfromzerocheck(armno,producttype,productpos)

						else:
							self.turnToAGV(armno,armno)
							self.goToAGV(armno,armno)
							self.moveWristBin(armno)
							gtraypose = self.placeToTray(armno,productpos,armno,initPose=pose)
							ariac_example.control_gripper(False, armno)
							self.goToAGV(armno,armno)
							ariac_example.control_gripper(True, armno)
							self.moveWristBin(armno)
							self.setorientation(armno,gtraypose,producttype)
							ariac_example.control_gripper(False, armno)
							rospy.sleep(1*self.delay)
							self.goToAGV(armno,armno)
						allflags[i] = self.checkwithTrayModels(producttype,productpos)
						countoftry[i] += 1
						if countoftry[i] == 2:
							allflags[i] = True

					elif passno>=2 and info=='need help':
						if self.debug:
							print("pick: need help ",producttype, passno, self.armno)
						if armno == 1:
							
							if rpy[0] != 0:
								self.commandpub.publish("1flip"+producttype)
							else:
								self.commandpub.publish("1"+producttype)
							while True:
								rospy.sleep(1*self.delay)
								if "done"==self.command:
									self.command = ""
									if rpy[0] != 0:
										self.pickfromzerocheck(armno,producttype,productpos,option=1)
										
									else:
										self.pickfromzerocheck(armno,producttype,productpos,option=0)
									break

							allflags[i] = self.checkwithTrayModels(producttype,productpos)
							countoftry[i] += 1
							if countoftry[i] == 2:
								allflags[i] = True

						if armno == 2:
							if self.command == "arm1done" or arm1doneflag or "arm1not working" == self.command:
								arm1doneflag = True
								
								if rpy[0] != 0:
									self.commandpub.publish("2flip"+producttype)
								else:
									self.commandpub.publish("2"+producttype)
								while True:
									rospy.sleep(1*self.delay)
									if "done"==self.command:
										self.command = ""
										if rpy[0] != 0:
											self.pickfromzerocheck(armno,producttype,productpos,option=1)
										else:
											self.pickfromzerocheck(armno,producttype,productpos,option=0)
										break

								allflags[i] = self.checkwithTrayModels(producttype,productpos)
								countoftry[i] += 1
								if countoftry[i] == 2:
									allflags[i] = True

							elif len(self.command)>0 and self.command[0] == '1':
								if self.command[1:5] == "flip":
									ptype = self.command[5:]
									self.putTozeroCheck(armno,ptype,option=1)
								else:
									ptype = self.command[1:]
									self.putTozeroCheck(armno,ptype)
								self.command = ""
							elif "grab_and_place" == self.command:
								self.grab_and_place(armno)
								
	
			passno += 1	
			if alltrue:
				break	

		if self.order_update:
			return

		ariac_example.control_agv(shipmentType, armno)
		if self.debug:
			print("*********************shipment  complete*****************************",self.armno)
		self.traymodels = []
		if armno==1:
			self.commandpub.publish("arm1done")
			while "arm2done" != self.command and "arm2not working" != self.command:
				rospy.sleep(1*self.delay)
				if len(self.command)>0 and self.command[0] == '2':
					if self.command[1:5] == "flip":
						ptype = self.command[5:]
						self.putTozeroCheck(armno,ptype,option=1)
					else:
						ptype = self.command[1:]
						self.putTozeroCheck(armno,ptype)
					self.command = ""
				elif "grab_and_place" == self.command:
					self.grab_and_place(armno)
					

		elif armno==2: 
			self.commandpub.publish("arm2done")

	def checkOrder(self,armno=1):
		counter = 0
		self.gotoHome(armno)
		if armno==1:
			self.starttime = self.simtime
			if self.debug:
				print(self.starttime,"********************************^^^^^^^^^^^^^^^^^^^^^^^^^ start time",self.armno)
			ariac_example.start_competition()
		rate = rospy.Rate(1.0)
		noofany = 0
		while not rospy.is_shutdown():
			if self.received_orders and len(self.received_orders)>0:
				order = self.received_orders[0]
				shipments = order.shipments
				if len(shipments)>=2:
					self.flipwillbechecked=False
				else:
					self.flipwillbechecked=True

				for shipment in shipments:
					self.shipmenttype = ""
					if 'any'==shipment.agv_id:
						noofany+=1

					if ('agv1'==shipment.agv_id  or 1==noofany) and armno==1:
						products = shipment.products
						self.ship(list(products),armno,shipment.shipment_type)
					elif ('agv2'==shipment.agv_id or 2==noofany) and armno==2:
						products = shipment.products
						self.ship(list(products),armno,shipment.shipment_type)
					if noofany==2:
						noofany = 0

				if self.order_update:
					self.order_update = False
					continue
				del self.received_orders[0]

			if len(self.command)>0 and self.command[0] == '1':
				if self.command[1:5] == "flip":
					ptype = self.command[5:]
					self.putTozeroCheck(armno,ptype,option=1)
				else:
					ptype = self.command[1:]
					self.putTozeroCheck(armno,ptype)
				self.command = ""
				rospy.sleep(3*self.delay)
			elif len(self.command)>0 and self.command[0] == '2':
				if self.command[1:5] == "flip":
					ptype = self.command[5:]
					self.putTozeroCheck(armno,ptype,option=1)
				else:
					ptype = self.command[1:]
					self.putTozeroCheck(armno,ptype)
				self.command = ""
				rospy.sleep(3*self.delay)

			if "grab_and_place" == self.command:
				self.grab_and_place(armno)


			if counter == 5:
				self.commandpub.publish("arm"+str(armno)+"not working")
				counter = 0
			counter += 1
			
			rate.sleep()

				
