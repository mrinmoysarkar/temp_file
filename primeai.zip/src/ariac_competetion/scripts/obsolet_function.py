	def gotoLocation(self,armno,location):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		
		x2 = location.position.x-0.1157
		y2 = location.position.y+0.114897
		z2 = location.position.z+0.0922
		
		xypoints = self.get2dTrajectory([x1,y1],[x2,y2])
		
		zpoint = np.linspace(z1,z2,xypoints.shape[1])
		waypoints = []
		for i in range(xypoints.shape[1]):
			x = xypoints[0][i]
			y = xypoints[1][i]
			z = zpoint[i]
    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z
    	
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2
		print(wpose)
		
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		#z transformcd

		self.moveWrist(armno)


	def get2dTrajectory(self,point1,point2):
		x1,y1=point1[0],point2[0]
		x2,y2=point1[1],point2[1]

		xc = (x1+x2)/2.0
		yc = (y1+y2)/2.0

		theta = atan2(y2-y1,x2-x1)

		a = sqrt((x1-x2)**2+(y1-y2)**2)/2
		b = 0.15
		t=np.linspace(0,np.pi,50)
		x = a*np.cos(t) 
		y = b*np.sin(t)
		
		mat = np.array([x,y])

		rotmat = np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])

		rotdata = np.matmul(rotmat,mat)
		rotdata[0]+=xc
		rotdata[1]+=yc

		return rotdata


	def setrpy(self,pose,rpy):
		quaternion = tf.transformations.quaternion_from_euler(rpy[0], rpy[1], rpy[2])
		pose.orientation.x = quaternion[0]
		pose.orientation.y = quaternion[1]
		pose.orientation.z = quaternion[2]
		pose.orientation.w = quaternion[3]
		return pose

		def grab(self,armno,height):
		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		if self.type == "piston_rod_part":
			wpose.position.z = height+0.01
		elif self.type == "gear_part":
			wpose.position.z = height+0.022 #-= 0.033 #0.033 for gear
		print("w pose z",wpose.position.z)
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		self.moveWrist(armno)
		# rospy.sleep(0.01)
		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.z += 0.1 
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

	def pick(self,armno,type):
		self.type = type
		self.gotoPickLocation(armno)
		self.pickFlag = True
		while self.pickFlag:
			rospy.sleep(0.1)
		
		h = self.getHeight()
		print("height",h)
		rospy.sleep(0.8)
		self.grab(armno,h)
		#self.move(pose)

	def place(self,pose,armno):
		self.move(pose,armno,pick=False)
		if self.ns[armno-1] == "/ariac/arm1":
				ariac_example.control_gripper(False, 1)
		elif self.ns[armno-1] == "/ariac/arm2":
				ariac_example.control_gripper(False, 2)

	def getHeight(self):
		frame = 'logical_camera_4_frame' 
		while not rospy.is_shutdown():
			try:
				trans = self.tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
				local_pose = geometry_msgs.msg.PoseStamped()
				local_pose.header.frame_id = frame
				local_pose.pose.position.x = self.refx
				local_pose.pose.position.y = self.refy
				local_pose.pose.position.z = self.refz
				self.refx = 0
				self.refy = 0
				self.refz = 0
				world_pose = self.tfBuffer.transform(local_pose, 'world')
				return world_pose.pose.position.z
				

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				print(e)
				continue

	def move(self,goalPos,armno,pick=True):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		# rpy = self.getrpy(start_pose)

		# print("roll:",rpy[0],"pitch:",rpy[1],"yaw:",rpy[2])
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		theta1 = atan2(y1,x1)

		x2 = goalPos.position.x-0.1157
		y2 = goalPos.position.y+0.114897
		z2 = goalPos.position.z+0.0922
		theta2 = atan2(y2,x2)

		step = 10 
		u = np.linspace(theta1,theta2,step)
		zval = np.linspace(z1,z2,step)
		d = sqrt((x1-x2)**2+(y1-y2)**2)
		r = max(0.3,d/2)
		waypoints = []
		for i in range(len(u)):
			x = (x1+x2)/2+r*cos(u[i])
			y = (y1+y2)/2+r*sin(u[i])
			z = zval[i]
    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z 
    		# wpose.orientation.w = 1
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2 
		# wpose.orientation.w = 1
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		self.moveWrist(armno)

		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		if pick:
			wpose.position.z -= 0.081
		else: 
			wpose.position.z -= 0.05
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

		if pick:
			self.moveWrist(armno,enable=True)
			rospy.sleep(0.5)
			
			waypoints = []
			wpose = self.move_group[armno-1].get_current_pose().pose
			wpose.position.z += 0.1 
			waypoints.append(copy.deepcopy(wpose))
			
			plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
			print(fraction)
			print(self.move_group[armno-1].execute(plan, wait=True))
			self.move_group[armno-1].stop()

	def gotoPickLocation(self,armno):
		goalPos = geometry_msgs.msg.Pose() 
		goalPos.position.x = 1.220003
		goalPos.position.y = 2.0
		goalPos.position.z = 0.91

		start_pose = self.move_group[armno-1].get_current_pose().pose
		
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		theta1 = atan2(y1,x1)

		x2 = goalPos.position.x-0.1157
		y2 = goalPos.position.y+0.114897
		z2 = goalPos.position.z+0.0922
		theta2 = atan2(y2,x2)

		step = 20 
		u = np.linspace(theta1,theta2,step)
		zval = np.linspace(z1,z2,step)
		d = sqrt((x1-x2)**2+(y1-y2)**2)
		r = max(0.3,d/2)
		waypoints = []
		for i in range(len(u)):
			x = (x1+x2)/2+r*cos(u[i])
			y = (y1+y2)/2+r*sin(u[i])
			z = zval[i]
    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z 
    		# wpose.orientation.w = 1
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2 
		# wpose.orientation.w = 1
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		self.moveWrist(armno,enable=True)

		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.z -= 0.05
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

	def moveWithgoalPose(self,goalPos,armno):
		start_pose = self.move_group[armno-1].get_current_pose().pose#goalPos
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		

		x2 = goalPos.position.x
		y2 = goalPos.position.y
		z2 = goalPos.position.z
		

		step = int(round(sqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)/0.1))
		u=np.linspace(0,0.9,step)
		
		for i in u:
			x = (1-i)*x1 + i*x2
			y = (1-i)*y1 + i*y2
			z = (1-i)*z1 + i*z2
			
			pose_goal = start_pose#geometry_msgs.msg.Pose()
			# pose_goal.orientation.x = 0
			# pose_goal.orientation.y = 0.707
			# pose_goal.orientation.z = 0
			# pose_goal.orientation.w = 0.707
			pose_goal.position.x = x
			pose_goal.position.y = y
			pose_goal.position.z = z

			self.move_group[armno-1].set_pose_target(pose_goal)
			if self.move_group[armno-1].go(wait=True):
				print("success")
				self.move_group[armno-1].stop()
				self.move_group[armno-1].clear_pose_targets()
				# return True
			else:
				print("failed to move the arm")
				# return False
		# pose_goal.orientation = goalPos.orientation
		# self.move_group[armno-1].set_pose_target(pose_goal)
		# if self.move_group[armno-1].go(wait=True):
		# 	print("success")
		# 	self.move_group[armno-1].stop()
		# 	self.move_group[armno-1].clear_pose_targets()
		# 	# return True
		# else:
		# 	print("failed to move the arm")
			# return False

	def pickFromCamera6(self,armno):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		start_pose.position.x = self.models[0].pose.position.x
		start_pose.position.y = self.models[0].pose.position.y
		start_pose.position.z = self.models[0].pose.position.z+.033
		self.move_group[armno-1].set_pose_target(start_pose)
		if self.move_group[armno-1].go(wait=True):
			print("success")
			self.move_group[armno-1].stop()
			self.move_group[armno-1].clear_pose_targets()
		self.moveWristBin(armno,enable=True)

	def moveWrist(self,armno,enable=False):
		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		# desired_angle = 3*pi/2-(joint_goal[2]+joint_goal[3])
		joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		# joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		# desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		# joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()
		# if enable:
		# 	if self.ns[armno-1] == "/ariac/arm1":
		# 		ariac_example.control_gripper(True, 1)
		# 	elif self.ns[armno-1] == "/ariac/arm2":
		# 		ariac_example.control_gripper(True, 2)


def putTozeroFrombelt(self,armno,producttype,cmd):
		flagdone = False 
		while not flagdone:
			rospy.sleep(1)
			if self.beltModels and armno==1:
				for model in self.beltModels:
					if model.type == producttype:
						pose = model.pose
						ariac_example.control_gripper(True, armno)
						self.turnToBelt(armno)
						rospy.sleep(2)
						self.goToAGVOnlyY(armno,armno)
						rospy.sleep(2)
						self.moveWristBin(armno)
						rospy.sleep(2)
						self.pickFromCamera(armno,pose,producttype)
						rospy.sleep(2)
						self.moveWristBin(armno)
						rospy.sleep(2)
						self.turnToBelt(armno)
						if armno == 1:
							self.goToCamera(armno,6)
						else:
							self.goToCamera(armno,7)
						rospy.sleep(2)
						self.putToZero(armno)
						rospy.sleep(2)
						self.turnToAGV(armno,armno)
						self.commandpub.publish(cmd+"done")
						return
					
			# self.beltStop = True
			# ariac_example.start_belt()
			# rospy.sleep(2)
			self.beltStop = False


def pick_place(self,armno_real):
		delay = 3

		if self.received_orders and len(self.received_orders)>0:
			
			order = self.received_orders[0]
			# print(order)
			shipments = order.shipments
			for shipment in shipments:
				# print(shipment)
				armno = 0
				if ('agv1'==shipment.agv_id or 'any'==shipment.agv_id) and armno_real != 2:
					armno = 1
					cmd = "arm1 working"
					self.commandpub.publish(cmd)
				elif armno_real == 2 and "arm1 working" == self.armnoWorking or self.armnoWorking == "default":
					return
				elif 'agv2'==shipment.agv_id:
					armno = 2

				if armno_real!=armno:
					continue

				print("armno: ",armno,shipment)
				print("**************************************************************")
				products = shipment.products
				for product in products:
					producttype = product.type
					productpos = product.pose
					flag = False
					if self.models:
						keys = self.models.keys()
						flag = False
						for key in keys:
							allModels = self.models[key]
							flag = False
							indx = -1
							for model in allModels:
								# print(model)
								indx = indx + 1
								if model.type == producttype:
									camerano = int(key[-1])
									pose = model.pose
									print("camera no", camerano)
									self.turnToBin(armno)
									flag1 = True
									if self.goToCamera(armno,camerano):
										del self.models[key][indx]
										print('arm',armno,' can pick')
										ariac_example.control_gripper(True, armno)
										rospy.sleep(2)
										self.moveWristBin(armno)
										self.pickFromCamera(armno,pose,producttype)
										self.moveWristBin(armno)
										self.turnToBin(armno)
										
										self.turnToAGV(armno,armno)
										self.goToAGV(armno,armno)
										self.moveWristBin(armno)
										gtraypose = self.placeToTray(armno,productpos,armno,initPose=pose)
										ariac_example.control_gripper(False, armno)
										self.goToAGV(armno,armno)
										ariac_example.control_gripper(True, armno)
										self.moveWristBin(armno)
										self.setorientation(armno,gtraypose,producttype)
										ariac_example.control_gripper(False, armno)
										rospy.sleep(1)
										self.goToAGV(armno,armno)
										flag1 = False
									if flag1:
										del self.models[key][indx]
										cmd = "puttozero"+str(armno)+" "+producttype
										self.commandpub.publish(cmd)
										cmd = cmd + "done"
										while self.command != cmd and not rospy.is_shutdown():
											rospy.sleep(1)
										self.pickFromzero(armno,producttype,productpos)
										rospy.sleep(delay)
										# print("................. Pick from Zero .................. ")
										self.turnToBin(armno)
										rospy.sleep(delay)
										# print("................. Turn to Bin .................. ")
										self.turnToAGV(armno,armno)
										rospy.sleep(delay)
										# print("................. Turn to AGV .................. ")
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										self.moveWristBin(armno)
										rospy.sleep(delay)
										# print("................. Move Wrist to Bin .................. ")
										gtraypose = self.placeToTray(armno,productpos,armno)
										rospy.sleep(delay)
										# print("................. Place to Tray .................. ")
										ariac_example.control_gripper(False, armno)
										rospy.sleep(delay)
										# print("................. Controller .................. ")
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										# print("................. Go to AGV .................. ")
										ariac_example.control_gripper(True, armno)
										rospy.sleep(delay)
										# print("................. Control Gripper .................. ")
										self.moveWristBin(armno)
										rospy.sleep(delay)
										# print("................. Wrist Movement to Bin for Orientation Control .................. ")
										self.setorientation(armno,gtraypose,producttype)
										rospy.sleep(delay)
										ariac_example.control_gripper(False, armno)
										rospy.sleep(delay)
										# rospy.sleep(armno)
										self.goToAGV(armno,armno)
										rospy.sleep(delay)
										self.command=""
									
									flag = True
									break
							if flag:
								break

					if not flag:
						# the model is not available in static bin
						# pick from belt
						if self.beltModels and armno==1:
							for model in self.beltModels:
								if model.type == producttype:
									pose = model.pose
									ariac_example.control_gripper(True, armno)
									self.turnToBelt(armno)
									rospy.sleep(delay)
									self.goToAGVOnlyY(armno,armno)
									rospy.sleep(delay)

									self.pickFromCamera(armno,pose,producttype)

									rospy.sleep(delay)
									self.turnToBelt(armno)
									self.beltStop = False
									rospy.sleep(delay)
									self.turnToAGV(armno,armno)
									rospy.sleep(delay)
									self.goToAGV(armno,armno)
									rospy.sleep(delay)
									self.moveWristBin(armno)
									gtraypose = self.placeToTray(armno,productpos,armno,initPose=pose)
									ariac_example.control_gripper(False, armno)
									self.goToAGV(armno,armno)
									ariac_example.control_gripper(True, armno)
									self.moveWristBin(armno)
									self.setorientation(armno,gtraypose,producttype)
									ariac_example.control_gripper(False, armno)
									rospy.sleep(1)
									self.goToAGV(armno,armno)
									
						elif armno==2:
							cmd = "frombelt"+str(armno)+" "+producttype
							self.commandpub.publish(cmd)
							cmd = cmd + "done"
							while self.command != cmd and not rospy.is_shutdown():
								rospy.sleep(1)
							self.pickFromzero(armno,producttype,productpos)
							rospy.sleep(delay)
							# print("................. Pick from Zero .................. ")
							self.turnToBin(armno)
							rospy.sleep(delay)
							# print("................. Turn to Bin .................. ")
							self.turnToAGV(armno,armno)
							rospy.sleep(delay)
							# print("................. Turn to AGV .................. ")
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							self.moveWristBin(armno)
							rospy.sleep(delay)
							# print("................. Move Wrist to Bin .................. ")
							gtraypose = self.placeToTray(armno,productpos,armno)
							rospy.sleep(delay)
							# print("................. Place to Tray .................. ")
							ariac_example.control_gripper(False, armno)
							rospy.sleep(delay)
							# print("................. Controller .................. ")
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							# print("................. Go to AGV .................. ")
							ariac_example.control_gripper(True, armno)
							rospy.sleep(delay)
							# print("................. Control Gripper .................. ")
							self.moveWristBin(armno)
							rospy.sleep(delay)
							# print("................. Wrist Movement to Bin for Orientation Control .................. ")
							self.setorientation(armno,gtraypose,producttype)
							rospy.sleep(delay)
							ariac_example.control_gripper(False, armno)
							rospy.sleep(delay)
							# rospy.sleep(armno)
							self.goToAGV(armno,armno)
							rospy.sleep(delay)
							self.command=""
						else:
							# ariac_example.start_belt()
							return
							
				ariac_example.control_agv(shipment.shipment_type, armno)
				print("*********************shipment  complete*****************************",armno)
			del self.received_orders[0]
			cmd = "arm1 not working"
			self.commandpub.publish(cmd)
			print("order complete")
			return


def dummy(self):
		armno,producttype=2,"pulley_part"
		keys = self.models.keys()
		for key in keys:
			allModels = self.models[key]
			flag = False
			indx = -1
			for model in allModels:
				# print(model)
				indx = indx + 1
				if model.type == producttype:
					camerano = int(key[-1])
					pose = model.pose
					print(camerano)
					self.turnToBin(armno)
					if self.goToCamera(armno,camerano):
						del self.models[key][indx]
						print('arm',armno,' can pick')
						ariac_example.control_gripper(True, armno)
						rospy.sleep(2)
						self.moveWristBin(armno)
						self.pickFromCamera(armno,pose,producttype)
						self.moveWristBin(armno)
						self.turnToBin(armno)
						if armno == 1:
							self.goToCamera(armno,6)
						else:
							self.goToCamera(armno,7)
						self.putToZeroFlip(armno)
						# self.turnToAGV(armno,armno)
						rospy.sleep(1)
						print("zero models: ", self.zeropointModels)
						for model in self.zeropointModels:
							if model.type == producttype:
								self.commandpub.publish("done")
								return								
						self.putTozeroCheck(armno,producttype)

	def dummy1(self):

		while self.command != "done":
			rospy.sleep(1)

		armno,producttype=1,"pulley_part"
		self.turnToBin(armno,option=1)

		# start_pose = self.move_group.get_current_pose().pose
		# start_pose.position.z = 1.45
		# try:
		# 	self.move_group.set_pose_target(start_pose)
		# 	self.move_group.go(wait=True)
		# except Exception as e:
		# 	print(e)
		# self.move_group.stop()
		# self.move_group.clear_pose_targets()
		# self.moveWristBin(armno)
		# rospy.sleep(1)

		self.moveWristBin(armno)
		# self.goToCamera(armno,6)
		ariac_example.control_gripper(True, armno)
		while not self.gripperState:
			self.pickFromzero(armno,producttype,option=1)
			rospy.sleep(1)
