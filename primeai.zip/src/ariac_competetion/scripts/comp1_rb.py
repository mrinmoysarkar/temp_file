#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt
from helperModule_rb import ArmController

flag = True
refPose = None



		



def logicalCamera1Callback(msg):
	global flag
	global refPose
	if flag:
		models = msg.models #it is a list
		print(models[0].type)
		print(models[0].pose)
		refPose = models[0].pose
		flag = False
	




if __name__ == '__main__':
	try:
		noOfarm = 2
		arm = ArmController("/ariac/arm",noOfarm)
		

		rospy.init_node('ariac_competetion_solution_node', anonymous=True)
		# rospy.Subscriber('/ariac/logical_camera_1',LogicalCameraImage,logicalCamera1Callback)

		arm.gotoHome(1)
		# arm2.gotoHome()
		
		# comp_class = ariac_example.MyCompetitionClass()
		# ariac_example.connect_callbacks(comp_class)
		rospy.sleep(2)
		# # rospy.loginfo("Setup complete.")
		# # # ariac_example.start_competition()

		# if not comp_class.arm_1_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_1_joint_trajectory_publisher)
		#     comp_class.arm_1_has_been_zeroed = True

		# if not comp_class.arm_2_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_2_joint_trajectory_publisher)
		#     comp_class.arm_2_has_been_zeroed = True

		golepose = geometry_msgs.msg.Pose() 
		golepose.position.x = -0.2
		golepose.position.y = 0.2336
		golepose.position.z = 1.5
		arm.gotoLocation(1,golepose)

		# rospy.sleep()

	except Exception as e:
		print(e)
