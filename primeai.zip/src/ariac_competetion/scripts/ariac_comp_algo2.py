#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt
# from helperModule import ArmController
from armController import ArmController

flag = True
refPose = None



		




	




if __name__ == '__main__':
	try:
		# rospy.init_node('ariac_competetion_solution_node2', anonymous=True)
		# noOfarm = 2
		# arm = ArmController("/ariac/arm",noOfarm)
		# arm1 = ArmController("/ariac/arm1")
		# arm1.checkOrder(1)
		arm2 = ArmController("/ariac/arm2",2)
		arm2.checkOrder(2)

		# rospy.init_node('ariac_competetion_solution_node', anonymous=True)
		#arm.gotoHomeAll()
		# arm.checkOrder()
		# arm.turnToBin(1)
		# arm.goToCamera(1,6)

		# arm.gotoHome(1)

		# arm.turnToBin(1)
		# rospy.sleep(1)
		# arm.goToCamera6(1)
		# rospy.sleep(1)
		# arm.pickFromCamera6(1)
		# rospy.sleep(1)
		# arm.turnToBin(1)
		# rospy.sleep(1)
		# arm.turnToAGV(1,1)
		# rospy.sleep(1)
		# arm.goToAGV(1,1)
		# rospy.sleep(1)
		# arm.placeToTray(1,1)
		# rospy.sleep(1)
		# arm.goToAGV(1,1)
		# rospy.sleep(1)
		# comp_class = ariac_example.MyCompetitionClass()
		# ariac_example.connect_callbacks(comp_class)
		
		# # rospy.loginfo("Setup complete.")
		# # # ariac_example.start_competition()

		# if not comp_class.arm_1_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_1_joint_trajectory_publisher)
		#     comp_class.arm_1_has_been_zeroed = True

		# if not comp_class.arm_2_has_been_zeroed:
		#     comp_class.send_arm_to_state([0] * len(comp_class.arm_joint_names), comp_class.arm_2_joint_trajectory_publisher)
		#     comp_class.arm_2_has_been_zeroed = True

		# golepose = geometry_msgs.msg.Pose() 
		# golepose.position.x = 1.22
		# golepose.position.y = 2.0
		# golepose.position.z = 0.91
		# arm.gotoLocation(1,golepose)
		# arm.pick(1,"gear_part")#"gear_part") #"piston_rod_part"
		# rospy.sleep(3)
		# arm1.gotoHome()
		# rospy.sleep(3)
		# golepose.position.x = 0.3
		# golepose.position.y = 3.15
		# golepose.position.z = 0.75
		# arm1.place(golepose)
		# arm1.pick()
		


		# tfBuffer = tf2_ros.Buffer()
		# listener = tf2_ros.TransformListener(tfBuffer)

		# # The shipping box TF frames are published by logical cameras, or can be published
		# # by user-created TF broadcasters.
		# frame = 'kit_tray_1'#'logical_camera_1_frame' #frame = 'shipping_box_frame'
		# rate = rospy.Rate(1.0)
		# # flag2 = True
		# while not rospy.is_shutdown():
		# # Ensure that the transform is available.
		# 	try:
		# 		trans = tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
		# 		local_pose = geometry_msgs.msg.PoseStamped()
		# 		local_pose.header.frame_id = frame
		# 		local_pose.pose.position.x = 0
		# 		local_pose.pose.position.y = 0
		# 		local_pose.pose.position.z = 0
		# 		world_pose = tfBuffer.transform(local_pose, 'world')
		# 		print(world_pose)
		# 		# arm1.move(world_pose.pose)
		# 		break

		# 	except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
		# 		print(e)
		# 		continue

			# Transform the pose from the specified frame to the world frame.
			# local_pose = geometry_msgs.msg.PoseStamped()
			# local_pose.header.frame_id = frame
			# local_pose.pose.position.x = 0.15
			# local_pose.pose.position.y = 0.15
			# # print(refPose)
			# if not flag and flag2:
			# 	flag2 = False
			# 	local_pose.pose = refPose
			# 	world_pose = tfBuffer.transform(local_pose, 'world')
			# 	# arm1.move(world_pose.pose)
			# 	# print(world_pose)
			# arm.checkOrder()
			# rate.sleep()
		# print("get out of loop",rospy.is_shutdown())	
		# arm1.moveWrist()
		# rospy.spin()

	except Exception as e:
		print(e)
