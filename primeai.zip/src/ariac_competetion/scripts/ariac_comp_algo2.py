#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt
# from helperModule import ArmController
from armController import ArmController


if __name__ == '__main__':
	try:
		arm2 = ArmController("/ariac/arm2",2)
		arm2.checkOrder(2)

	except Exception as e:
		print(e)
		print("error from main 2")
