#!/usr/bin/env python
# author: Mrinmoy sarkar
# date: 7 April 2019
# email: mrinmoy.pol@gmail.com

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
import ariac_example
import geometry_msgs.msg
import rospy
import tf
import tf2_ros
import tf2_geometry_msgs 
from osrf_gear.msg import LogicalCameraImage
import numpy as np
from math import sqrt,pi,atan2,cos,sin
from osrf_gear.msg import Proximity
from osrf_gear.msg import LogicalCameraImage
import time





class ArmController():
	def __init__(self,ns,noOfarm):
		moveit_commander.roscpp_initialize(sys.argv)
		self.robot = []
		self.scene = []
		self.move_group = []
		self.ns = []
		for i in range(noOfarm):
			robot = moveit_commander.RobotCommander(robot_description=ns+str(i+1)+"/robot_description",ns=ns+str(i+1))
			scene = moveit_commander.PlanningSceneInterface(ns=ns)
			group_name = "manipulator"
			move_group = moveit_commander.MoveGroupCommander(group_name,robot_description=ns+str(i+1)+"/robot_description",ns=ns+str(i+1))
			self.robot.append(robot)
			self.scene.append(scene)
			self.move_group.append(move_group)
			self.ns.append(ns+str(i+1))
		# print(self.ns)
		# move_group_wrist = moveit_commander.MoveGroupCommander("endeffector",robot_description=ns+"/robot_description",ns=ns)

		# planning_frame = move_group.get_planning_frame()
		# eef_link = move_group.get_end_effector_link()
		# group_names = robot.get_group_names()

		
		# self.move_group_wrist = move_group_wrist
		# self.planning_frame = planning_frame
		# self.eef_link = eef_link
		# self.group_names = group_names
		
		self.pickFlag = False
		self.modelsaveFlag = False
		self.models = []
		self.indx = 0
		self.previousTime = 0
		self.refx = 0
		self.refy = 0
		self.refz = 0
		self.type = ""
		rospy.Subscriber("/ariac/break_beam_1_change",Proximity,self.breakbeam1Callback)
		rospy.Subscriber("/ariac/break_beam_2_change",Proximity,self.breakbeam2Callback)
		rospy.Subscriber("/ariac/break_beam_3_change",Proximity,self.breakbeam3Callback)
		rospy.Subscriber('/ariac/logical_camera_4',LogicalCameraImage,self.logicalCamera14Callback)
		# rospy.Subscriber('/ariac/logical_camera_6',LogicalCameraImage,self.logicalCamera16Callback)


	def breakbeam1Callback(self,msg):
		if msg.object_detected and self.pickFlag:
			print("one object found")
			model = self.models[0]
			if model.type == self.type:
				self.refx = model.pose.position.x
				self.refy = model.pose.position.y
				self.refz = model.pose.position.z
				self.pickFlag = False
			del self.models[0]

	def logicalCamera16Callback(self,msg):
			models = msg.models #it is a list
			frame = 'logical_camera_6_frame' 
			if models:
				print('***********************')
				for model in models:
					pose=model.pose
					gpose=self.getglobalpose(frame,pose)
					print(gpose)
				print('***********************')
				
		

	def breakbeam2Callback(self,msg):
		if msg.object_detected:
			# self.indx -= 1
			self.modelsaveFlag = True

	def breakbeam3Callback(self,msg):
		if msg.object_detected:#and (time.time() - self.previousTime) > 1:
			self.indx += 1
			# print('indx',self.indx)
			# self.previousTime = time.time()
		
	def logicalCamera14Callback(self,msg):

		if self.modelsaveFlag:
			# print(msg.models)
			# print('************')
			models = msg.models #it is a list
			if models:
				self.models.append(models[-1])
			self.modelsaveFlag = False
			
			# print((self.models))
		# print(models[0].type)
		# print(models[0].pose)
		# refPose = models[0].pose

	def gotoHome(self,armno):
		# self.move_group[armno-1].set_named_target("home")
		# self.move_group[armno-1].set_named_target("up")
		# print(self.move_group[armno-1].go(wait=True))

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		joint_goal[0] = 0 # linear_arm_actuator_joint
		joint_goal[1] = pi/2 # shoulder_pan_joint
		joint_goal[2] = -pi/2 # shoulder_lift_joint
		joint_goal[3] = pi/4 # elbow_joint 
		
		joint_goal[4] = 0#-3*pi/2 #wrist_1_joint
		joint_goal[5] = 0 #wrist_2_joint
		joint_goal[6] = 0 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

	def moveWithgoalPose(self,goalPos,armno):
		start_pose = self.move_group[armno-1].get_current_pose().pose#goalPos
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		

		x2 = goalPos.position.x
		y2 = goalPos.position.y
		z2 = goalPos.position.z
		

		step = int(round(sqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)/0.1))
		u=np.linspace(0,0.9,step)
		
		for i in u:
			x = (1-i)*x1 + i*x2
			y = (1-i)*y1 + i*y2
			z = (1-i)*z1 + i*z2
			
			pose_goal = start_pose#geometry_msgs.msg.Pose()
			# pose_goal.orientation.x = 0
			# pose_goal.orientation.y = 0.707
			# pose_goal.orientation.z = 0
			# pose_goal.orientation.w = 0.707
			pose_goal.position.x = x
			pose_goal.position.y = y
			pose_goal.position.z = z

			self.move_group[armno-1].set_pose_target(pose_goal)
			if self.move_group[armno-1].go(wait=True):
				print("success")
				self.move_group[armno-1].stop()
				self.move_group[armno-1].clear_pose_targets()
				# return True
			else:
				print("failed to move the arm")
				# return False
		# pose_goal.orientation = goalPos.orientation
		# self.move_group[armno-1].set_pose_target(pose_goal)
		# if self.move_group[armno-1].go(wait=True):
		# 	print("success")
		# 	self.move_group[armno-1].stop()
		# 	self.move_group[armno-1].clear_pose_targets()
		# 	# return True
		# else:
		# 	print("failed to move the arm")
			# return False

	def moveWrist(self,armno,enable=False):
		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		# joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()

		joint_goal = self.move_group[armno-1].get_current_joint_values()
		# print('joint gole',joint_goal)
		# joint_goal[0] += 0.2 # linear_arm_actuator_joint
		# joint_goal[1] += 0.2 # shoulder_pan_joint
		# joint_goal[2] += 0.2 # shoulder_lift_joint
		# joint_goal[3] += 0.2 # elbow_joint 
		# desired_angle = -pi/2-(joint_goal[2]+joint_goal[3])
		# joint_goal[4] += (desired_angle - joint_goal[4]) #wrist_1_joint
		joint_goal[5] += (-pi/2- joint_goal[5]) #wrist_2_joint
		# joint_goal[6] = pi/2 # wrist_3_joint

		self.move_group[armno-1].go(joint_goal, wait=True)
		self.move_group[armno-1].stop()
		if enable:
			if self.ns[armno-1] == "/ariac/arm1":
				ariac_example.control_gripper(True, 1)
			elif self.ns[armno-1] == "/ariac/arm2":
				ariac_example.control_gripper(True, 2)

	def move(self,goalPos,armno,pick=True):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		# rpy = self.getrpy(start_pose)

		# print("roll:",rpy[0],"pitch:",rpy[1],"yaw:",rpy[2])
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		theta1 = atan2(y1,x1)

		x2 = goalPos.position.x-0.1157
		y2 = goalPos.position.y+0.114897
		z2 = goalPos.position.z+0.0922
		theta2 = atan2(y2,x2)

		step = 10 
		u = np.linspace(theta1,theta2,step)
		zval = np.linspace(z1,z2,step)
		d = sqrt((x1-x2)**2+(y1-y2)**2)
		r = max(0.3,d/2)
		waypoints = []
		for i in range(len(u)):
			x = (x1+x2)/2+r*cos(u[i])
			y = (y1+y2)/2+r*sin(u[i])
			z = zval[i]
    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z 
    		# wpose.orientation.w = 1
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2 
		# wpose.orientation.w = 1
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		self.moveWrist(armno)

		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		if pick:
			wpose.position.z -= 0.081
		else: 
			wpose.position.z -= 0.05
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

		if pick:
			self.moveWrist(armno,enable=True)
			rospy.sleep(0.5)
			
			waypoints = []
			wpose = self.move_group[armno-1].get_current_pose().pose
			wpose.position.z += 0.1 
			waypoints.append(copy.deepcopy(wpose))
			
			plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
			print(fraction)
			print(self.move_group[armno-1].execute(plan, wait=True))
			self.move_group[armno-1].stop()

	def gotoPickLocation(self,armno):
		goalPos = geometry_msgs.msg.Pose() 
		goalPos.position.x = 1.220003
		goalPos.position.y = 2.0
		goalPos.position.z = 0.91

		start_pose = self.move_group[armno-1].get_current_pose().pose
		
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		theta1 = atan2(y1,x1)

		x2 = goalPos.position.x-0.1157
		y2 = goalPos.position.y+0.114897
		z2 = goalPos.position.z+0.0922
		theta2 = atan2(y2,x2)

		step = 20 
		u = np.linspace(theta1,theta2,step)
		zval = np.linspace(z1,z2,step)
		d = sqrt((x1-x2)**2+(y1-y2)**2)
		r = max(0.3,d/2)
		waypoints = []
		for i in range(len(u)):
			x = (x1+x2)/2+r*cos(u[i])
			y = (y1+y2)/2+r*sin(u[i])
			z = zval[i]
    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z 
    		# wpose.orientation.w = 1
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2 
		# wpose.orientation.w = 1
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		self.moveWrist(armno,enable=True)

		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.z -= 0.05
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

	def grab(self,armno,height):
		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		if self.type == "piston_rod_part":
			wpose.position.z = height+0.01
		elif self.type == "gear_part":
			wpose.position.z = height+0.022 #-= 0.033 #0.033 for gear
		print("w pose z",wpose.position.z)
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		self.moveWrist(armno)
		# rospy.sleep(0.01)
		waypoints = []
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.z += 0.1 
		waypoints.append(copy.deepcopy(wpose))
		
		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()

	def pick(self,armno,type):
		self.type = type
		self.gotoPickLocation(armno)
		self.pickFlag = True
		while self.pickFlag:
			rospy.sleep(0.1)
		
		h = self.getHeight()
		print("height",h)
		rospy.sleep(0.8)
		self.grab(armno,h)
		#self.move(pose)

	def place(self,pose,armno):
		self.move(pose,armno,pick=False)
		if self.ns[armno-1] == "/ariac/arm1":
				ariac_example.control_gripper(False, 1)
		elif self.ns[armno-1] == "/ariac/arm2":
				ariac_example.control_gripper(False, 2)

	def getrpy(self,pose):
		quaternion = (
		pose.orientation.x,
		pose.orientation.y,
		pose.orientation.z,
		pose.orientation.w)
		euler = tf.transformations.euler_from_quaternion(quaternion)
		roll = euler[0]
		pitch = euler[1]
		yaw = euler[2]
		return euler

	def setrpy(self,pose,rpy):
		quaternion = tf.transformations.quaternion_from_euler(rpy[0], rpy[1], rpy[2])
		pose.orientation.x = quaternion[0]
		pose.orientation.y = quaternion[1]
		pose.orientation.z = quaternion[2]
		pose.orientation.w = quaternion[3]
		return pose

	def getHeight(self):
		tfBuffer = tf2_ros.Buffer()
		listener = tf2_ros.TransformListener(tfBuffer)

		frame = 'logical_camera_4_frame' 
		
		
		while not rospy.is_shutdown():
		# Ensure that the transform is available.
			try:
				trans = tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
				local_pose = geometry_msgs.msg.PoseStamped()
				local_pose.header.frame_id = frame
				local_pose.pose.position.x = self.refx
				local_pose.pose.position.y = self.refy
				local_pose.pose.position.z = self.refz
				self.refx = 0
				self.refy = 0
				self.refz = 0
				world_pose = tfBuffer.transform(local_pose, 'world')
				return world_pose.pose.position.z
				

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				print(e)
				continue

	def getglobalpose(self,frame,pose):
		tfBuffer = tf2_ros.Buffer()
		listener = tf2_ros.TransformListener(tfBuffer)
	
		
		while not rospy.is_shutdown():
		# Ensure that the transform is available.
			try:
				trans = tfBuffer.lookup_transform('world', frame, rospy.Time(), rospy.Duration(1.0))
				local_pose = geometry_msgs.msg.PoseStamped()
				local_pose.header.frame_id = frame
				local_pose.pose=pose

				world_pose = tfBuffer.transform(local_pose, 'world')
				return world_pose
				

			except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
				print(e)
				continue

	def get2dTrajectory(self,point1,point2):
		x1,y1=point1[0],point2[0]
		x2,y2=point1[1],point2[1]

		xc = (x1+x2)/2.0
		yc = (y1+y2)/2.0

		theta = atan2(y2-y1,x2-x1)

		a = sqrt((x1-x2)**2+(y1-y2)**2)/2
		b = 0.15
		t=np.linspace(0,np.pi,50)
		x = a*np.cos(t) 
		y = b*np.sin(t)
		
		mat = np.array([x,y])

		rotmat = np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])

		rotdata = np.matmul(rotmat,mat)
		rotdata[0]+=xc
		rotdata[1]+=yc

		return rotdata

	def gotoLocation(self,armno,location):
		start_pose = self.move_group[armno-1].get_current_pose().pose
		x1 = start_pose.position.x
		y1 = start_pose.position.y
		z1 = start_pose.position.z
		
		x2 = location.position.x-0.1157
		y2 = location.position.y+0.114897
		z2 = location.position.z+0.0922
		theta1 = atan2(y1,x1)
		theta2 = atan2(y2,x2)

		step = 20 
		u = np.linspace(theta1,theta2,step)
		zval = np.linspace(z1,z2,step)
		d = sqrt((x1-x2)**2+(y1-y2)**2)
		r = max(0.3,d/2)
		waypoints = []
		for i in range(len(u)):
			x = (x1+x2)/2+r*cos(u[i])
			y = (y1+y2)/2+r*sin(u[i])
			z = zval[i]

    		wpose = self.move_group[armno-1].get_current_pose().pose
    		wpose.position.x = x 
    		wpose.position.y = y
    		wpose.position.z = z
    	
    		waypoints.append(copy.deepcopy(wpose))
		wpose = self.move_group[armno-1].get_current_pose().pose
		wpose.position.x = x2 
		wpose.position.y = y2
		wpose.position.z = z2
		print(wpose)
		
		waypoints.append(copy.deepcopy(wpose))
		

		plan, fraction = self.move_group[armno-1].compute_cartesian_path(waypoints, 0.01, 0.0) 
		print(fraction)
		print(self.move_group[armno-1].execute(plan, wait=True))
		self.move_group[armno-1].stop()
		
		#z transformcd

		self.moveWrist(armno)